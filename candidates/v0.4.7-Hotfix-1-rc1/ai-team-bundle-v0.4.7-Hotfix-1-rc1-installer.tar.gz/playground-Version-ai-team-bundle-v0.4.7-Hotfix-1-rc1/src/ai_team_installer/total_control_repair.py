from __future__ import annotations

import re
from pathlib import Path
from typing import Any

try:
    import yaml
except ModuleNotFoundError:
    yaml = None


PROJECT_AUTHORITY_HOST = Path("00-项目包") / "04-过程文件" / "00-沟通记录与结论回写.md"
DELIVERY_OWNER_BLOCK_PATTERN = re.compile(
    r"^### Delivery Owner Record (?P<identifier>[^\n]+)\n+```yaml\n(?P<payload>.*?)```",
    re.MULTILINE | re.DOTALL,
)
DELIVERY_OWNER_HEADING_PATTERN = re.compile(r"^### Delivery Owner Record ", re.MULTILINE)
REQUIRED_DELIVERY_OWNER_KEYS = (
    "schema",
    "task_chain_id",
    "task_chain_epoch",
    "authority_record_version",
    "scope_level",
    "scope_path",
    "当前责任模式",
    "模式来源",
    "二次握手结果",
    "锁存范围",
    "退出条件",
    "当前状态",
)


class TotalControlRepairBlockedError(Exception):
    def __init__(self, *, summary: str, reason_code: str, host_path: Path | None = None) -> None:
        super().__init__(summary)
        self.summary = summary
        self.reason_code = reason_code
        self.host_path = host_path

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "result": "blocked",
            "reason_code": self.reason_code,
            "summary": self.summary,
        }
        if self.host_path is not None:
            payload["authority_host"] = self.host_path.as_posix()
        return payload


def repair_total_control_authority(project_root: Path, *, install_mode: str) -> dict[str, Any]:
    if install_mode != "repair":
        return {"status": "skipped", "reason": "fresh_install"}

    host_path = project_root / PROJECT_AUTHORITY_HOST
    created_host = False
    if not host_path.exists():
        host_path.parent.mkdir(parents=True, exist_ok=True)
        host_path.write_text("# 沟通记录与结论回写\n", encoding="utf-8")
        created_host = True

    text = host_path.read_text(encoding="utf-8")
    records = _parse_delivery_owner_records(text, host_path)
    if records:
        return {
            "status": "unchanged",
            "host_path": PROJECT_AUTHORITY_HOST.as_posix(),
            "created_host": created_host,
        }

    updated_text = _append_repair_baseline(text)
    host_path.write_text(updated_text, encoding="utf-8")
    return {
        "status": "backfilled",
        "host_path": PROJECT_AUTHORITY_HOST.as_posix(),
        "created_host": created_host,
        "task_chain_id": "tc-repair-bootstrap",
    }


def _parse_delivery_owner_records(text: str, host_path: Path) -> list[dict[str, Any]]:
    headings = DELIVERY_OWNER_HEADING_PATTERN.findall(text)
    matches = list(DELIVERY_OWNER_BLOCK_PATTERN.finditer(text))
    if headings and len(headings) != len(matches):
        raise TotalControlRepairBlockedError(
            summary="authority carrier contains an unparseable Delivery Owner Record block",
            reason_code="authority_carrier_unparseable",
            host_path=host_path,
        )

    parsed_records: list[dict[str, Any]] = []
    for match in matches:
        payload = _parse_delivery_owner_payload(match.group("payload"), host_path)
        if payload.get("schema") != "total_control.delivery_owner_record.v1":
            raise TotalControlRepairBlockedError(
                summary="authority carrier Delivery Owner Record schema is invalid",
                reason_code="authority_carrier_unparseable",
                host_path=host_path,
            )
        missing_keys = [key for key in REQUIRED_DELIVERY_OWNER_KEYS if key not in payload]
        if missing_keys:
            raise TotalControlRepairBlockedError(
                summary="authority carrier Delivery Owner Record is missing required fields: " + ", ".join(missing_keys),
                reason_code="authority_carrier_unparseable",
                host_path=host_path,
            )
        parsed_records.append(payload)
    return parsed_records


def _parse_delivery_owner_payload(payload_text: str, host_path: Path) -> dict[str, Any]:
    if yaml is not None:
        try:
            payload = yaml.safe_load(payload_text)
        except Exception as exc:  # noqa: BLE001 - normalize PyYAML errors, then try legacy markdown scalars
            try:
                payload = _parse_delivery_owner_legacy_mapping(payload_text)
            except ValueError:
                raise TotalControlRepairBlockedError(
                    summary=f"authority carrier contains invalid Delivery Owner Record yaml: {exc}",
                    reason_code="authority_carrier_unparseable",
                    host_path=host_path,
                ) from None
        else:
            if not isinstance(payload, dict):
                raise TotalControlRepairBlockedError(
                    summary="authority carrier contains invalid Delivery Owner Record yaml: expected mapping",
                    reason_code="authority_carrier_unparseable",
                    host_path=host_path,
                )
            return payload
    else:
        try:
            payload = _parse_delivery_owner_legacy_mapping(payload_text)
        except ValueError as exc:
            raise TotalControlRepairBlockedError(
                summary=f"authority carrier contains invalid Delivery Owner Record yaml: {exc}",
                reason_code="authority_carrier_unparseable",
                host_path=host_path,
            ) from None
    if not isinstance(payload, dict):
        raise TotalControlRepairBlockedError(
            summary="authority carrier contains invalid Delivery Owner Record yaml: expected mapping",
            reason_code="authority_carrier_unparseable",
            host_path=host_path,
        )
    return payload


def _parse_delivery_owner_legacy_mapping(payload_text: str) -> dict[str, Any]:
    payload: dict[str, Any] = {}
    lines = payload_text.splitlines()
    index = 0
    while index < len(lines):
        raw_line = lines[index]
        stripped = raw_line.strip()
        if not stripped or stripped.startswith("#"):
            index += 1
            continue
        if raw_line[:1].isspace():
            index += 1
            continue
        if stripped.startswith("- "):
            index += 1
            continue
        key, separator, value = raw_line.partition(":")
        if not separator:
            raise ValueError("expected `key: value` lines")
        normalized_key = key.strip()
        normalized_value = value.strip()
        if not normalized_key:
            raise ValueError("empty key")
        if _looks_like_unclosed_flow_value(normalized_value):
            raise ValueError("unclosed flow value")
        if normalized_value:
            payload[normalized_key] = normalized_value
            index += 1
            continue
        items: list[str] = []
        lookahead = index + 1
        while lookahead < len(lines):
            child_line = lines[lookahead]
            child_stripped = child_line.strip()
            if not child_stripped:
                lookahead += 1
                continue
            if child_stripped.startswith("- "):
                items.append(child_stripped[2:].strip())
                lookahead += 1
                while lookahead < len(lines):
                    continuation = lines[lookahead]
                    continuation_stripped = continuation.strip()
                    if not continuation_stripped:
                        lookahead += 1
                        continue
                    if continuation.startswith((" ", "\t")):
                        lookahead += 1
                        continue
                    break
                continue
            break
        payload[normalized_key] = items if items else None
        index = lookahead
    return payload


def _looks_like_unclosed_flow_value(value: str) -> bool:
    if not value:
        return False
    return (value.startswith("[") and not value.endswith("]")) or (value.startswith("{") and not value.endswith("}"))


def _append_repair_baseline(text: str) -> str:
    stripped = text.rstrip()
    separator = "\n\n" if stripped else ""
    baseline = "\n".join(
        [
            "### Delivery Owner Record tc-repair-bootstrap#1",
            "```yaml",
            "schema: total_control.delivery_owner_record.v1",
            "task_chain_id: tc-repair-bootstrap",
            "task_chain_epoch: 1",
            "authority_record_version: 1",
            "scope_level: project",
            f"scope_path: {PROJECT_AUTHORITY_HOST.as_posix()}",
            "当前责任模式: standard",
            "模式来源: repair_bootstrap_recovery",
            "二次握手结果: not_required",
            "锁存范围: repair_bootstrap_scope",
            "退出条件: total_control_first_opening",
            "当前状态: standard",
            "```",
        ]
    )
    return stripped + separator + baseline + "\n"
