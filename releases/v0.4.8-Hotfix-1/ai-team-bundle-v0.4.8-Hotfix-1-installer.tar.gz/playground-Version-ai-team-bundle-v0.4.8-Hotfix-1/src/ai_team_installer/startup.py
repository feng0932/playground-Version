from __future__ import annotations

from pathlib import Path
import re


DEFAULT_FIRST_USE_ENTRY_COMMAND = "/总控 请接管当前项目，并授权派发子agent"


def runtime_total_control_prompt_source(project_root: Path, runtime_root: Path) -> Path:
    return (project_root / runtime_root.relative_to(project_root) / "agents" / "00-编排-总控.agent.md").resolve()


def render_startup_prompt(template_path: Path, project_root: Path, prompt_source: Path) -> str:
    template = template_path.read_text(encoding="utf-8")
    return (
        template.replace("{{project_root}}", str(project_root))
        .replace("{{prompt_source}}", str(prompt_source))
        .strip()
    )


def extract_human_entry_command(startup_prompt: str) -> str:
    for pattern in (
        r"第一次进入方法论提示语是 `([^`]+)`",
        r"安装后最小正式入口动作是 `([^`]+)`",
    ):
        match = re.search(pattern, startup_prompt)
        if match and match.group(1).strip():
            return match.group(1).strip()
    return DEFAULT_FIRST_USE_ENTRY_COMMAND
