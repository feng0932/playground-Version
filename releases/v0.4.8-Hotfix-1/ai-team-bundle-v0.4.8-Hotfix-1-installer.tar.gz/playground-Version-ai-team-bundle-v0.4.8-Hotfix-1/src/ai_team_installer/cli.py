from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

from .doctor import collect_doctor
from .install import InstallBlockedError, install_project
from .state import collect_status


def _format_install_success(result: dict[str, Any], project_root: Path) -> str:
    bundle_version = result.get("bundle_version") or "unknown"
    release_tag = result.get("release_tag") or "unknown"
    entry_command = result.get("human_entry_command") or "/总控 请接管当前项目，并授权派发子agent"
    log_path = result.get("install_summary_path") or str(project_root / ".ai-team" / "state" / "install-summary.json")
    return "\n".join(
        [
            "安装完成，可以进入方法论。",
            f"下一步：在项目根目录打开 Codex，输入：`{entry_command}`",
            f"安装版本：{bundle_version} / {release_tag}",
            "当前状态：机器入口已安装；项目运行时已就绪；总控入口已就绪，将进入：/总控",
            f"完整日志：{log_path}",
        ]
    )


def _format_install_blocked(payload: dict[str, Any], project_root: Path) -> str:
    reason_code = str(payload.get("reason_code") or "install_blocked")
    summary = str(payload.get("summary") or "install blocked")
    suggested_action = str(payload.get("suggested_action") or "查看完整日志后按真实失败原因修复，再重新运行 ai-team install。")
    blocked_stage = _blocked_stage_for_reason(reason_code)
    log_path = project_root / ".ai-team" / "state" / "governance-log.jsonl"
    return "\n".join(
        [
            "还不能进入方法论。",
            f"卡住位置：{blocked_stage}；reason_code={reason_code}",
            f"原因：{summary}",
            f"下一步：{suggested_action}",
            "当前状态：机器入口=ready；项目运行时=blocked；总控入口=not_checked",
            f"完整日志：{log_path}",
        ]
    )


def _blocked_stage_for_reason(reason_code: str) -> str:
    if reason_code in {"release_metadata_missing", "release_metadata_unreadable", "release_metadata_invalid"}:
        return "读取 release metadata"
    if reason_code in {"runtime_bundle_source_missing"}:
        return "安装项目运行时"
    if reason_code in {"governance_script_diverged"}:
        return "项目治理脚本保护"
    if reason_code in {"methodology_source_repo_root_forbidden"}:
        return "安装前检查"
    return "安装执行链"


def _ensure_utf8_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            reconfigure(encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ai_team_installer")
    subparsers = parser.add_subparsers(dest="command", required=True)

    install_parser = subparsers.add_parser("install")
    install_parser.add_argument("--project-root", required=False)
    install_parser.add_argument("--allow-downgrade", action="store_true")
    install_parser.add_argument("--repair-governance-scripts", action="store_true")

    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("--project-root", required=False)

    doctor_parser = subparsers.add_parser("doctor")
    doctor_parser.add_argument("--project-root", required=False)

    runtime_parser = subparsers.add_parser("runtime")
    runtime_parser.add_argument("--project-root", required=False)
    runtime_parser.add_argument(
        "--action",
        required=True,
        choices=["total_control_entry", "build_dispatch_request", "read_receipt"],
    )
    runtime_parser.add_argument("--receipt-file", required=False)
    runtime_parser.add_argument("--receipt-text", required=False)

    return parser


def main(argv: list[str] | None = None) -> int:
    _ensure_utf8_stdio()
    parser = build_parser()
    args = parser.parse_args(argv)
    project_root_arg = getattr(args, "project_root", None)
    project_root = Path(project_root_arg).resolve() if project_root_arg else Path.cwd().resolve()

    if args.command == "install":
        try:
            result = install_project(
                project_root,
                allow_downgrade=args.allow_downgrade,
                repair_governance_scripts=args.repair_governance_scripts,
            )
        except InstallBlockedError as exc:
            print(_format_install_blocked(exc.payload, project_root))
            return 1
        print(_format_install_success(result, project_root))
        for warning in result.get("warnings", []):
            print(f"warning: {warning}")
        return 0

    if args.command == "status":
        print(json.dumps(collect_status(project_root), ensure_ascii=False, indent=2))
        return 0

    if args.command == "doctor":
        print(json.dumps(collect_doctor(project_root), ensure_ascii=False, indent=2))
        return 0

    if args.command == "runtime":
        try:
            from .runtime_entry import RuntimeEntryError, execute_runtime_action
        except Exception as exc:
            print(
                json.dumps(
                    {
                        "ok": False,
                        "action": "runtime_bootstrap",
                        "decision": "runtime_import_failed",
                        "summary": f"{exc.__class__.__name__}: {exc}",
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 3
        try:
            payload = execute_runtime_action(
                project_root,
                action=args.action,
                receipt_file=args.receipt_file,
                receipt_text=args.receipt_text,
            )
        except RuntimeEntryError as exc:
            print(json.dumps(exc.payload, ensure_ascii=False, indent=2))
            return exc.exit_code
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    parser.error(f"unsupported command: {args.command}")
    return 2
