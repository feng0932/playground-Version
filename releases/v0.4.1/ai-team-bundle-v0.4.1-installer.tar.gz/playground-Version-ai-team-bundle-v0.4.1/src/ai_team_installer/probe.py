from __future__ import annotations

from pathlib import Path


IGNORE_RULES = (
    ".ai-team/",
)


def ensure_hidden_workspace_ignored(project_root: Path) -> str:
    exclude_file = project_root / ".git" / "info" / "exclude"
    if exclude_file.parent.exists():
        exclude_file.parent.mkdir(parents=True, exist_ok=True)
        return _ensure_rules(exclude_file)

    gitignore_file = project_root / ".gitignore"
    return _ensure_rules(gitignore_file)


def _ensure_rules(path: Path) -> str:
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    rules = existing.splitlines()
    missing_rules = [rule for rule in IGNORE_RULES if rule not in rules]
    if missing_rules:
        if existing and not existing.endswith("\n"):
            existing += "\n"
        existing += "".join(f"{rule}\n" for rule in missing_rules)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(existing, encoding="utf-8")
    return str(path)


def probe_structure(project_root: Path) -> dict[str, object]:
    return {
        "project_root": str(project_root),
        "facts": {
            "has_git_repo": (project_root / ".git").exists(),
            "has_readme": (project_root / "README.md").exists(),
            "has_src_dir": (project_root / "src").exists(),
            "has_tests_dir": (project_root / "tests").exists(),
            "has_project_package_dir": (project_root / "00-项目包").exists(),
            "has_project_baseline_01": (project_root / "00-项目包" / "01-项目商业说明.md").exists(),
            "has_project_baseline_02": (project_root / "00-项目包" / "02-用户画像与权限架构.md").exists(),
            "has_project_baseline_03": (project_root / "00-项目包" / "03-系统拓扑与核心名词表.md").exists(),
            "has_module_execution_dir": (project_root / "01-模块执行包").exists(),
            "has_submission_package_dir": (project_root / "80-完整提交包").exists(),
            "has_submission_status_json": (project_root / "80-完整提交包" / "00-提交状态.json").exists(),
            "has_legacy_toolkit_dir": (project_root / ".ai-team" / "toolkit").exists(),
            "has_docs_root_note": (project_root / "docs" / "00-说明.md").exists(),
            "has_docs_cross_module_readme": (project_root / "docs" / "01-跨模块补充资料" / "README.md").exists(),
        },
    }
