"""Minimal local installer package for step-1 contract validation."""

__all__ = ["__version__"]

__version__ = "0.1.0"
