from __future__ import annotations

import re
from pathlib import Path
from typing import Any


PROJECT_AUTHORITY_HOST = Path("00-项目包") / "04-过程文件" / "00-沟通记录与结论回写.md"
DELIVERY_OWNER_BLOCK_PATTERN = re.compile(
    r"^### Delivery Owner Record (?P<identifier>[^\n]+)\n+```yaml\n(?P<payload>.*?)```",
    re.MULTILINE | re.DOTALL,
)
DELIVERY_OWNER_HEADING_PATTERN = re.compile(r"^### Delivery Owner Record ", re.MULTILINE)
REQUIRED_DELIVERY_OWNER_KEYS = (
    "schema",
    "task_chain_id",
    "task_chain_epoch",
    "authority_record_version",
    "scope_level",
    "scope_path",
    "当前责任模式",
    "模式来源",
    "二次握手结果",
    "锁存范围",
    "退出条件",
    "当前状态",
)


class TotalControlRepairBlockedError(Exception):
    def __init__(self, *, summary: str, reason_code: str, host_path: Path | None = None) -> None:
        super().__init__(summary)
        self.summary = summary
        self.reason_code = reason_code
        self.host_path = host_path

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "result": "blocked",
            "reason_code": self.reason_code,
            "summary": self.summary,
        }
        if self.host_path is not None:
            payload["authority_host"] = self.host_path.as_posix()
        return payload


def repair_total_control_authority(project_root: Path, *, install_mode: str) -> dict[str, Any]:
    if install_mode != "repair":
        return {"status": "skipped", "reason": "fresh_install"}

    host_path = project_root / PROJECT_AUTHORITY_HOST
    created_host = False
    if not host_path.exists():
        host_path.parent.mkdir(parents=True, exist_ok=True)
        host_path.write_text("# 沟通记录与结论回写\n", encoding="utf-8")
        created_host = True

    text = host_path.read_text(encoding="utf-8")
    records = _parse_delivery_owner_records(text, host_path)
    if records:
        return {
            "status": "unchanged",
            "host_path": PROJECT_AUTHORITY_HOST.as_posix(),
            "created_host": created_host,
        }

    updated_text = _append_repair_baseline(text)
    host_path.write_text(updated_text, encoding="utf-8")
    return {
        "status": "backfilled",
        "host_path": PROJECT_AUTHORITY_HOST.as_posix(),
        "created_host": created_host,
        "task_chain_id": "tc-repair-bootstrap",
    }


def _parse_delivery_owner_records(text: str, host_path: Path) -> list[dict[str, Any]]:
    headings = DELIVERY_OWNER_HEADING_PATTERN.findall(text)
    matches = list(DELIVERY_OWNER_BLOCK_PATTERN.finditer(text))
    if headings and len(headings) != len(matches):
        raise TotalControlRepairBlockedError(
            summary="authority carrier contains an unparseable Delivery Owner Record block",
            reason_code="authority_carrier_unparseable",
            host_path=host_path,
        )

    parsed_records: list[dict[str, Any]] = []
    for match in matches:
        payload = _parse_delivery_owner_payload(match.group("payload"), host_path)
        if payload.get("schema") != "total_control.delivery_owner_record.v1":
            raise TotalControlRepairBlockedError(
                summary="authority carrier Delivery Owner Record schema is invalid",
                reason_code="authority_carrier_unparseable",
                host_path=host_path,
            )
        missing_keys = [key for key in REQUIRED_DELIVERY_OWNER_KEYS if key not in payload]
        if missing_keys:
            raise TotalControlRepairBlockedError(
                summary="authority carrier Delivery Owner Record is missing required fields: " + ", ".join(missing_keys),
                reason_code="authority_carrier_unparseable",
                host_path=host_path,
            )
        parsed_records.append(payload)
    return parsed_records


def _parse_delivery_owner_payload(payload_text: str, host_path: Path) -> dict[str, str]:
    payload: dict[str, str] = {}
    for raw_line in payload_text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        key, separator, value = raw_line.partition(":")
        if not separator:
            raise TotalControlRepairBlockedError(
                summary="authority carrier contains invalid Delivery Owner Record yaml: expected `key: value` lines",
                reason_code="authority_carrier_unparseable",
                host_path=host_path,
            )
        normalized_key = key.strip()
        normalized_value = value.lstrip()
        if not normalized_key or not normalized_value:
            raise TotalControlRepairBlockedError(
                summary="authority carrier contains invalid Delivery Owner Record yaml: empty key or value",
                reason_code="authority_carrier_unparseable",
                host_path=host_path,
            )
        payload[normalized_key] = normalized_value
    return payload


def _append_repair_baseline(text: str) -> str:
    stripped = text.rstrip()
    separator = "\n\n" if stripped else ""
    baseline = "\n".join(
        [
            "### Delivery Owner Record tc-repair-bootstrap#1",
            "```yaml",
            "schema: total_control.delivery_owner_record.v1",
            "task_chain_id: tc-repair-bootstrap",
            "task_chain_epoch: 1",
            "authority_record_version: 1",
            "scope_level: project",
            f"scope_path: {PROJECT_AUTHORITY_HOST.as_posix()}",
            "当前责任模式: standard",
            "模式来源: repair_bootstrap_recovery",
            "二次握手结果: not_required",
            "锁存范围: repair_bootstrap_scope",
            "退出条件: total_control_first_opening",
            "当前状态: standard",
            "```",
        ]
    )
    return stripped + separator + baseline + "\n"
