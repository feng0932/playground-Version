from __future__ import annotations

from pathlib import Path


def runtime_total_control_prompt_source(project_root: Path, runtime_root: Path) -> Path:
    return (project_root / runtime_root.relative_to(project_root) / "agents" / "00-编排-总控.agent.md").resolve()


def render_startup_prompt(template_path: Path, project_root: Path, prompt_source: Path) -> str:
    template = template_path.read_text(encoding="utf-8")
    return (
        template.replace("{{project_root}}", str(project_root))
        .replace("{{prompt_source}}", str(prompt_source))
        .strip()
    )
