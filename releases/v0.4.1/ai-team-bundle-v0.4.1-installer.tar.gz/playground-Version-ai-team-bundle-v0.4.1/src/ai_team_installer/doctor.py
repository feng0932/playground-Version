from __future__ import annotations

from pathlib import Path
from typing import Any

from .machine_state import describe_machine_vs_project, read_machine_install_state
from .state import safe_read_json


def collect_doctor(project_root: Path) -> dict[str, Any]:
    lock_payload = safe_read_json(project_root / "ai-team.lock.json")
    runtime_payload = safe_read_json(project_root / ".ai-team" / "runtime.json")
    install_payload = safe_read_json(project_root / ".ai-team" / "install.json")
    machine_payload = read_machine_install_state()

    machine_version = _payload_str(machine_payload, "bundle_version")
    project_runtime_version = _payload_str(runtime_payload, "bundle_version")
    comparison = describe_machine_vs_project(machine_version, project_runtime_version)
    risk_level, recommended_action = _classify_risk(comparison=comparison, runtime_payload=runtime_payload)

    return {
        "project_root": str(project_root),
        "machine": {
            "launcher_bundle_version": machine_version,
            "release_tag": _payload_str(machine_payload, "release_tag"),
            "release_metadata_path": _payload_str(machine_payload, "release_metadata_path"),
        },
        "project": {
            "lock": {
                "bundle_version": _payload_str(lock_payload, "bundle_version"),
            },
            "runtime": {
                "bundle_version": project_runtime_version,
                "bundle_root": _payload_str(runtime_payload, "bundle_root"),
            },
            "install": {
                "release_metadata_path": _payload_str(install_payload, "release_metadata_path"),
            },
        },
        "comparison": {
            "machine_vs_project": comparison,
        },
        "risk_level": risk_level,
        "recommended_action": recommended_action,
    }


def _classify_risk(*, comparison: str, runtime_payload: dict[str, Any] | None) -> tuple[str, str]:
    if runtime_payload is None:
        return ("info", "run_ai_team_install")
    if comparison == "older":
        return ("high", "upgrade_machine_launcher_before_reinstall")
    if comparison == "newer":
        return ("info", "safe_to_reinstall")
    if comparison == "same":
        return ("none", "safe_to_install")
    return ("unknown", "inspect_versions")


def _payload_str(payload: dict[str, Any] | None, key: str) -> str | None:
    if payload is None:
        return None
    value = payload.get(key)
    if isinstance(value, str) and value:
        return value
    return None
