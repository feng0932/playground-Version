from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


GOVERNANCE_LOG_RELATIVE_PATH = Path(".ai-team") / "state" / "governance-log.jsonl"
GOVERNANCE_LATEST_RELATIVE_PATH = Path(".ai-team") / "state" / "governance-latest.json"


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def safe_read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return read_json(path)
    except json.JSONDecodeError:
        return None


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def append_governance_event(
    project_root: Path,
    *,
    event_type: str,
    bundle_version: str | None,
    release_tag: str | None,
    event_scope: str = "canonical",
    latest_eligible: bool | None = None,
    project_ref: str | None = None,
    input_refs: list[str] | None = None,
    output_refs: list[str] | None = None,
    result: str,
    warnings: list[str] | None = None,
    blockers: list[str] | None = None,
    written_targets: list[str] | None = None,
    snapshot_targets: list[str] | None = None,
    reason_code: str | None = None,
    conflicting_files: list[str] | None = None,
    suggested_action: str | None = None,
) -> dict[str, Any]:
    normalized_project_root = project_root.resolve()
    if event_scope not in {"canonical", "probe"}:
        raise ValueError(f"Unsupported governance event scope: {event_scope}")
    if latest_eligible is None:
        latest_eligible = event_scope == "canonical" and result == "ok"
    event = {
        "schema_version": 1,
        "event_type": event_type,
        "event_scope": event_scope,
        "latest_eligible": latest_eligible,
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "bundle_version": bundle_version,
        "release_tag": release_tag,
        "project_root": project_ref or str(normalized_project_root),
        "input_refs": list(input_refs or []),
        "output_refs": list(output_refs or []),
        "result": result,
        "warnings": list(warnings or []),
        "blockers": list(blockers or []),
        "written_targets": list(written_targets or []),
        "snapshot_hashes": _snapshot_hashes_for_refs(normalized_project_root, snapshot_targets or written_targets or []),
    }
    if reason_code is not None:
        event["reason_code"] = reason_code
    if conflicting_files is not None:
        event["conflicting_files"] = list(conflicting_files)
    if suggested_action is not None:
        event["suggested_action"] = suggested_action

    log_path = normalized_project_root / GOVERNANCE_LOG_RELATIVE_PATH
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False) + "\n")

    if latest_eligible:
        write_json(normalized_project_root / GOVERNANCE_LATEST_RELATIVE_PATH, event)
    return event


def collect_status(project_root: Path) -> dict[str, Any]:
    lock_file = project_root / "ai-team.lock.json"
    install_file = project_root / ".ai-team" / "install.json"
    runtime_file = project_root / ".ai-team" / "runtime.json"
    summary_file = project_root / ".ai-team" / "state" / "install-summary.json"
    probe_file = project_root / ".ai-team" / "state" / "structure-probe.json"
    catalog_file = project_root / ".ai-team" / "state" / "bundle-catalog.json"
    startup_prompt = project_root / ".ai-team" / "state" / "startup-prompt.txt"
    governance_log = project_root / GOVERNANCE_LOG_RELATIVE_PATH
    governance_latest = project_root / GOVERNANCE_LATEST_RELATIVE_PATH

    files = {
        "lock": lock_file.exists(),
        "install": install_file.exists(),
        "runtime": runtime_file.exists(),
        "install_summary": summary_file.exists(),
        "structure_probe": probe_file.exists(),
        "bundle_catalog": catalog_file.exists(),
        "startup_prompt": startup_prompt.exists(),
        "governance_log": governance_log.exists(),
        "governance_latest": governance_latest.exists(),
    }
    installed = all(files.values())
    expected_runtime_root = project_root / ".ai-team" / "runtime" / "default_bundle"
    legacy_runtime_root = project_root / ".ai-team" / "toolkit" / "default_bundle"

    lock_payload = safe_read_json(lock_file)
    install_payload = safe_read_json(install_file)
    runtime_payload = safe_read_json(runtime_file)
    summary_payload = safe_read_json(summary_file)
    probe_payload = safe_read_json(probe_file)
    catalog_payload = safe_read_json(catalog_file)
    governance_latest_payload = safe_read_json(governance_latest)
    effective_governance_payload = _effective_governance_payload_for_status(project_root, governance_latest_payload)
    missing_project_state_governance_event = bool(
        governance_latest_payload is not None
        and governance_latest_payload.get("event_type") == "release_check"
        and effective_governance_payload is None
    )

    bundle_root = None
    if runtime_payload is not None:
        bundle_root_raw = runtime_payload.get("bundle_root")
        if isinstance(bundle_root_raw, str) and bundle_root_raw:
            bundle_root = Path(bundle_root_raw)

    legacy_footprint_exists = legacy_runtime_root.exists()
    runtime_points_to_legacy_toolkit_path = _path_has_suffix(bundle_root, ("toolkit", "default_bundle"))
    runtime_points_to_current_runtime_root = bundle_root == expected_runtime_root
    runtime_root_missing = bool(bundle_root is not None and not bundle_root.exists())

    blockers = []
    warnings = []
    if runtime_points_to_legacy_toolkit_path:
        blockers.append("active runtime record points to old toolkit path")
    elif runtime_root_missing:
        blockers.append("active runtime root missing")
    elif bundle_root is not None and not runtime_points_to_current_runtime_root:
        blockers.append("active runtime record points to unexpected bundle root")
    elif legacy_footprint_exists and runtime_points_to_current_runtime_root:
        warnings.append("legacy footprint exists but active runtime is current")

    governance_mismatches = _governance_snapshot_mismatches(project_root, effective_governance_payload)
    if governance_latest.exists() and governance_latest_payload is None:
        blockers.append("governance latest snapshot is unreadable")
    elif missing_project_state_governance_event:
        blockers.append("governance latest snapshot has no project-state governance event for status drift checks")
    elif governance_mismatches:
        blockers.append(
            "governance ledger snapshot mismatch: " + ", ".join(governance_mismatches)
        )

    project_root_matches = (
        install_payload is not None
        and runtime_payload is not None
        and install_payload.get("project_root") == str(project_root)
        and runtime_payload.get("project_root") == str(project_root)
    )

    bundle_catalog_assets_exist = False
    runtime_startup_source_exists = False
    org_skill_readme_exists = False
    skill_contracts_exist = False
    if catalog_payload is not None and runtime_payload is not None and bundle_root is not None:
        resolved_assets = catalog_payload.get("resolved_assets")
        if isinstance(resolved_assets, dict):
            bundle_catalog_assets_exist = True
            for paths in resolved_assets.values():
                if not isinstance(paths, list):
                    bundle_catalog_assets_exist = False
                    break
                for raw_path in paths:
                    if not isinstance(raw_path, str) or not raw_path:
                        bundle_catalog_assets_exist = False
                        break
                    if not Path(raw_path).exists():
                        bundle_catalog_assets_exist = False
                        break
                if not bundle_catalog_assets_exist:
                    break

    manifest_roots_declared = False
    if bundle_root is not None:
        manifest_path = bundle_root / "manifest.json"
        manifest_payload = safe_read_json(manifest_path)
        if manifest_payload is not None:
            manifest_roots_declared = all(
                isinstance(manifest_payload.get(key), str) and manifest_payload.get(key)
                for key in ("agents_root", "assets_root", "org_skill_root")
            )
            startup_prompt_rel = manifest_payload.get("startup_prompt")
            if isinstance(startup_prompt_rel, str) and startup_prompt_rel:
                runtime_startup_source_exists = (bundle_root / startup_prompt_rel).exists()

            org_skill_readme_rel = manifest_payload.get("org_skill_readme")
            if isinstance(org_skill_readme_rel, str) and org_skill_readme_rel:
                org_skill_readme_exists = (bundle_root / org_skill_readme_rel).exists()

            skills = manifest_payload.get("skills")
            org_skill_root = manifest_payload.get("org_skill_root")
            if isinstance(skills, list) and isinstance(org_skill_root, str) and org_skill_root:
                skill_contracts_exist = True
                for skill_name in skills:
                    if not isinstance(skill_name, str) or not skill_name:
                        skill_contracts_exist = False
                        break
                    skill_root = bundle_root / org_skill_root / skill_name
                    if not skill_root.is_dir() or not (skill_root / "SKILL.md").exists():
                        skill_contracts_exist = False
                        break

    validation = {
        "install_json_readable": install_payload is not None,
        "lock_json_readable": lock_payload is not None,
        "runtime_json_readable": runtime_payload is not None,
        "install_summary_json_readable": summary_payload is not None,
        "structure_probe_json_readable": probe_payload is not None,
        "bundle_catalog_json_readable": catalog_payload is not None,
        "governance_latest_json_readable": governance_latest_payload is not None,
        "governance_snapshot_match": not governance_mismatches and not missing_project_state_governance_event,
        "bundle_root_exists": bool(bundle_root and bundle_root.exists()),
        "legacy_footprint_exists": legacy_footprint_exists,
        "runtime_points_to_legacy_toolkit_path": runtime_points_to_legacy_toolkit_path,
        "runtime_points_to_current_runtime_root": runtime_points_to_current_runtime_root,
        "runtime_root_missing": runtime_root_missing,
        "bundle_version_match": (
            lock_payload is not None
            and runtime_payload is not None
            and lock_payload.get("bundle_version") == runtime_payload.get("bundle_version")
        ),
        "project_root_match": project_root_matches,
        "manifest_roots_declared": manifest_roots_declared,
        "runtime_startup_source_exists": runtime_startup_source_exists,
        "org_skill_readme_exists": org_skill_readme_exists,
        "skill_contracts_exist": skill_contracts_exist,
        "bundle_catalog_assets_exist": bundle_catalog_assets_exist,
    }
    overall_state = _derive_overall_state(installed, validation, blockers)

    return {
        "project_root": str(project_root),
        "installed": installed,
        "overall_state": overall_state,
        "files": files,
        "validation": validation,
        "warnings": warnings,
        "blockers": blockers,
        "runtime_source": {
            "active_bundle_root": str(bundle_root) if bundle_root is not None else None,
            "expected_bundle_root": str(expected_runtime_root),
        },
    }

def _derive_overall_state(installed: bool, validation: dict[str, bool], blockers: list[str]) -> str:
    if not installed:
        return "blocked"
    if blockers:
        return "blocked"
    readiness_keys = (
        "install_json_readable",
        "lock_json_readable",
        "runtime_json_readable",
        "install_summary_json_readable",
        "structure_probe_json_readable",
        "bundle_catalog_json_readable",
        "governance_latest_json_readable",
        "governance_snapshot_match",
        "bundle_root_exists",
        "runtime_points_to_current_runtime_root",
        "bundle_version_match",
        "project_root_match",
        "manifest_roots_declared",
        "runtime_startup_source_exists",
        "org_skill_readme_exists",
        "skill_contracts_exist",
        "bundle_catalog_assets_exist",
    )
    if all(validation.get(key, False) for key in readiness_keys):
        return "ready"
    return "stale"


def _path_has_suffix(path: Path | None, suffix_parts: tuple[str, ...]) -> bool:
    if path is None:
        return False
    parts = path.parts
    suffix_length = len(suffix_parts)
    return len(parts) >= suffix_length and parts[-suffix_length:] == suffix_parts


def _snapshot_hashes_for_refs(project_root: Path, refs: list[str]) -> dict[str, str]:
    snapshot_hashes: dict[str, str] = {}
    for ref in refs:
        relative_ref = _normalize_ref(ref)
        if not relative_ref:
            continue
        target = project_root / relative_ref
        if not target.exists() or not target.is_file():
            continue
        snapshot_hashes[relative_ref] = hashlib.sha256(target.read_bytes()).hexdigest()
    return snapshot_hashes


def _governance_snapshot_mismatches(project_root: Path, latest_payload: dict[str, Any] | None) -> list[str]:
    if latest_payload is None:
        return []
    required_refs = _required_snapshot_refs(latest_payload)
    snapshot_hashes = latest_payload.get("snapshot_hashes")
    if not isinstance(snapshot_hashes, dict) or not snapshot_hashes:
        return sorted(required_refs) if required_refs else ["governance snapshot missing"]

    mismatches: list[str] = []
    for ref in sorted(required_refs):
        if ref not in snapshot_hashes:
            mismatches.append(ref)

    for ref, expected_hash in snapshot_hashes.items():
        if not isinstance(ref, str) or not ref:
            continue
        if not isinstance(expected_hash, str) or not expected_hash:
            continue
        relative_ref = _normalize_ref(ref)
        target = project_root / relative_ref
        if not target.exists() or not target.is_file():
            mismatches.append(relative_ref)
            continue
        actual_hash = hashlib.sha256(target.read_bytes()).hexdigest()
        if actual_hash != expected_hash:
            mismatches.append(relative_ref)
    return mismatches


def _effective_governance_payload_for_status(
    project_root: Path,
    latest_payload: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if latest_payload is None:
        return _last_project_state_governance_event(project_root)
    if _is_project_state_governance_event(latest_payload):
        return latest_payload
    return _last_project_state_governance_event(project_root)


def _last_project_state_governance_event(project_root: Path) -> dict[str, Any] | None:
    log_path = project_root / GOVERNANCE_LOG_RELATIVE_PATH
    if not log_path.exists():
        return None

    for line in reversed(log_path.read_text(encoding="utf-8").splitlines()):
        if not line.strip():
            continue
        try:
            payload = json.loads(line)
        except json.JSONDecodeError:
            continue
        if _is_project_state_governance_event(payload):
            return payload
    return None


def _is_project_state_governance_event(payload: dict[str, Any]) -> bool:
    return _event_scope(payload) == "canonical" and _latest_eligible(payload)


def _event_scope(payload: dict[str, Any]) -> str:
    value = payload.get("event_scope")
    if value in {"canonical", "probe"}:
        return value
    if payload.get("event_type") == "release_check":
        return "probe"
    return "canonical"


def _latest_eligible(payload: dict[str, Any]) -> bool:
    value = payload.get("latest_eligible")
    if isinstance(value, bool):
        return value
    return _event_scope(payload) == "canonical" and payload.get("result") == "ok"


def _required_snapshot_refs(latest_payload: dict[str, Any]) -> set[str]:
    required_refs = set(_normalized_ref_list(latest_payload.get("written_targets")))
    if latest_payload.get("event_type") in {"submission_status_sync", "gate_b_check"}:
        required_refs.update(_normalized_ref_list(latest_payload.get("input_refs")))
    return required_refs


def _normalized_ref_list(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    normalized: list[str] = []
    for value in values:
        if not isinstance(value, str) or not value:
            continue
        normalized.append(_normalize_ref(value))
    return normalized


def _normalize_ref(ref: str) -> str:
    normalized = Path(ref).as_posix()
    if normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized
