from __future__ import annotations

import json
import locale
import os
import re
import hashlib
import subprocess
import sys
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .state import collect_status, safe_read_json


AUTHORITY_HOST = Path("00-项目包") / "04-过程文件" / "00-沟通记录与结论回写.md"
PRIMARY_WINDOW_AGENTS = {
    "01-编排-初始化项目包": "project_package_initialization",
    "10-执行-产品专家": "product_source_completion",
}
NO_PRIMARY_WINDOW_NEXT_HOP = "no_primary_window_next_hop"
AUTHORITY_REPLAY_RETENTION_FIELD_MAP = {
    "latest_consumed_receipt_consumed": "receipt_consumed",
    "latest_consumed_receipt_dispatch_instance_id": "dispatch_instance_id",
    "latest_consumed_receipt_task_chain_id": "task_chain_id",
    "latest_consumed_receipt_task_chain_epoch": "task_chain_epoch",
    "latest_consumed_receipt_child_thread": "child_thread",
    "latest_consumed_receipt_current_phase": "current_phase",
    "latest_consumed_receipt_return_reason": "return_reason",
    "latest_consumed_receipt_recommended_return_target": "recommended_return_target",
    "latest_consumed_receipt_user_rejudge_intent_summary": "user_rejudge_intent_summary",
    "latest_consumed_receipt_user_rejudge_affected_scope": "user_rejudge_affected_scope",
    "latest_consumed_receipt_user_rejudge_requested_direction": "user_rejudge_requested_direction",
    "latest_consumed_receipt_screening_result_gate_status": "screening_result_gate_status",
    "latest_consumed_receipt_screening_result_ref_path": "screening_result_ref_path",
    "latest_consumed_receipt_screening_result_ref_anchor_or_section": "screening_result_ref_anchor_or_section",
    "latest_consumed_receipt_screening_result_ref_owner_agent": "screening_result_ref_owner_agent",
    "latest_consumed_receipt_screening_result_ref_task_chain_id": "screening_result_ref_task_chain_id",
    "latest_consumed_receipt_screening_result_ref_task_chain_epoch": "screening_result_ref_task_chain_epoch",
    "latest_consumed_receipt_screening_result_ref_gate_status": "screening_result_ref_gate_status",
    "latest_consumed_receipt_screening_result_ref_sha256": "screening_result_ref_sha256",
    "latest_consumed_receipt_required_formal_targets": "required_formal_targets",
    "latest_consumed_receipt_formal_targets_write_authorized": "formal_targets_write_authorized",
    "latest_consumed_receipt_formal_targets_written": "formal_targets_written",
    "latest_consumed_receipt_formal_targets_existing": "formal_targets_existing",
    "latest_consumed_receipt_formal_targets_missing": "formal_targets_missing",
    "latest_consumed_receipt_project_package_ready": "project_package_ready",
    "latest_consumed_receipt_project_package_result_ref_path": "project_package_result_ref_path",
    "latest_consumed_receipt_project_package_result_ref_owner_agent": "project_package_result_ref_owner_agent",
    "latest_consumed_receipt_project_package_result_ref_task_chain_id": "project_package_result_ref_task_chain_id",
    "latest_consumed_receipt_project_package_result_ref_task_chain_epoch": "project_package_result_ref_task_chain_epoch",
    "latest_consumed_receipt_project_package_result_ref_gate_status": "project_package_result_ref_gate_status",
    "latest_consumed_receipt_project_package_result_ref_sha256": "project_package_result_ref_sha256",
    "latest_consumed_receipt_project_package_result_ref_canonicalization": "project_package_result_ref_canonicalization",
    "latest_consumed_receipt_deepening_result_gate_status": "deepening_result_gate_status",
    "latest_consumed_receipt_deepening_result_ref_path": "deepening_result_ref_path",
    "latest_consumed_receipt_deepening_result_ref_anchor_or_section": "deepening_result_ref_anchor_or_section",
    "latest_consumed_receipt_deepening_result_ref_owner_agent": "deepening_result_ref_owner_agent",
    "latest_consumed_receipt_deepening_result_ref_task_chain_id": "deepening_result_ref_task_chain_id",
    "latest_consumed_receipt_deepening_result_ref_task_chain_epoch": "deepening_result_ref_task_chain_epoch",
    "latest_consumed_receipt_deepening_result_ref_gate_status": "deepening_result_ref_gate_status",
    "latest_consumed_receipt_deepening_result_ref_sha256": "deepening_result_ref_sha256",
    "latest_consumed_receipt_structure_blocker_owner": "structure_blocker_owner",
    "latest_consumed_receipt_structure_blocker_code": "structure_blocker_code",
    "latest_consumed_receipt_delivery_mode_explicit": "delivery_mode_explicit",
    "latest_consumed_receipt_active_module_set_explicit": "active_module_set_explicit",
    "latest_consumed_receipt_module_structure_ready": "module_structure_ready",
    "latest_consumed_receipt_writable_targets_ready": "writable_targets_ready",
    "latest_consumed_receipt_next_10_writable_targets": "next_10_writable_targets",
}
CR004_RECEIPT_HANDOFF_FIELDS = (
    "screening_result_gate_status",
    "screening_result_ref_path",
    "screening_result_ref_anchor_or_section",
    "screening_result_ref_owner_agent",
    "screening_result_ref_task_chain_id",
    "screening_result_ref_task_chain_epoch",
    "screening_result_ref_gate_status",
    "screening_result_ref_sha256",
    "required_formal_targets",
    "formal_targets_write_authorized",
    "formal_targets_written",
    "formal_targets_existing",
    "formal_targets_missing",
    "project_package_ready",
    "project_package_result_ref_path",
    "project_package_result_ref_owner_agent",
    "project_package_result_ref_task_chain_id",
    "project_package_result_ref_task_chain_epoch",
    "project_package_result_ref_gate_status",
    "project_package_result_ref_sha256",
    "project_package_result_ref_canonicalization",
    "deepening_result_gate_status",
    "deepening_result_ref_path",
    "deepening_result_ref_anchor_or_section",
    "deepening_result_ref_owner_agent",
    "deepening_result_ref_task_chain_id",
    "deepening_result_ref_task_chain_epoch",
    "deepening_result_ref_gate_status",
    "deepening_result_ref_sha256",
    "delivery_mode_explicit",
    "active_module_set_explicit",
    "module_structure_ready",
    "writable_targets_ready",
    "next_10_writable_targets",
)
STRUCTURE_BLOCKER_OWNER = "01_structure_governance"
STRUCTURE_BLOCKER_CODES = {
    "prd_write_target_missing",
    "module_structure_missing",
    "writable_targets_missing",
    "active_module_set_missing",
    "delivery_mode_missing",
}
EXECUTION_STRUCTURE_BOOLEAN_FIELDS = (
    "delivery_mode_explicit",
    "active_module_set_explicit",
    "module_structure_ready",
    "writable_targets_ready",
)
RECORD_PATTERN = re.compile(
    r"^### (?P<label>Delivery Owner Record|Dispatch Snapshot Record) (?P<identifier>[^\n]+)\n```yaml\n(?P<payload>.*?)```",
    re.MULTILINE | re.DOTALL,
)
TERMINAL_RECEIPT_PATTERN = re.compile(
    r"^### (?P<label>(?:[^\n]+ )?Terminal Receipt [^\n]+)\n(?P<body>.*?)(?=^### |\Z)",
    re.MULTILINE | re.DOTALL,
)


class RuntimeEntryError(Exception):
    def __init__(self, *, payload: dict[str, Any], exit_code: int = 1) -> None:
        super().__init__(str(payload.get("summary") or payload.get("decision") or "runtime entry failed"))
        self.payload = payload
        self.exit_code = exit_code


@dataclass
class StructuredRecord:
    label: str
    identifier: str
    payload: dict[str, Any]
    start: int
    end: int


@dataclass
class AuthorityCarrierState:
    path: Path
    text: str
    records: list[StructuredRecord]

    @property
    def latest_delivery_owner(self) -> StructuredRecord | None:
        for record in reversed(self.records):
            if record.label == "Delivery Owner Record":
                return record
        return None

    @property
    def latest_dispatch_snapshot(self) -> StructuredRecord | None:
        for record in reversed(self.records):
            if record.label == "Dispatch Snapshot Record":
                return record
        return None


@dataclass
class PromptBuilderResult:
    dispatch_prompt: str
    role_prompt_sha256: str | None


@dataclass
class DispatchInputContractArtifact:
    path: str
    sha256: str


def execute_runtime_action(
    project_root: Path,
    *,
    action: str,
    receipt_file: str | None = None,
    receipt_text: str | None = None,
) -> dict[str, Any]:
    runtime_root = _load_runtime_root(project_root)
    if action == "total_control_entry":
        return _handle_total_control_entry(project_root, runtime_root, action=action)
    if action == "build_dispatch_request":
        return _handle_total_control_entry(project_root, runtime_root, action=action)
    if action == "read_receipt":
        carrier_text = _resolve_receipt_text(project_root, receipt_file=receipt_file, receipt_text=receipt_text)
        return _handle_read_receipt(project_root, runtime_root, receipt_carrier=carrier_text)
    raise RuntimeEntryError(
        payload={
            "ok": False,
            "action": action,
            "decision": "schema_error",
            "summary": f"unsupported runtime action: {action}",
        },
        exit_code=2,
    )


def _handle_total_control_entry(project_root: Path, runtime_root: Path, *, action: str) -> dict[str, Any]:
    carrier = _ensure_authority_carrier(project_root)
    latest_delivery = carrier.latest_delivery_owner
    if latest_delivery is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": action,
                "decision": "authority_blocked",
                "summary": "authority carrier is missing a Delivery Owner Record",
            }
        )
    retained_status = _extract_retained_latest_status(latest_delivery.payload)
    status_payload = collect_status(project_root)
    if not _install_runtime_ready_for_total_control(status_payload, runtime_root):
        return _dispatch_via_resolver(
            project_root,
            runtime_root,
            action=action,
            authority_snapshot=_build_authority_snapshot(
                latest_delivery.payload,
                dispatch_instance_id=_new_dispatch_instance_id("02"),
            ),
            latest_status={},
            dispatch_intent="install_runtime_check",
            dispatch_request={"target_agent": "02-编排-安装与运行检查"},
        )
    if _retained_receipt_reopens_10(retained_status):
        authority_snapshot = _build_authority_snapshot(
            latest_delivery.payload,
            dispatch_instance_id=_new_dispatch_instance_id("10"),
            retained_status=retained_status,
        )
        dispatch_request = {"target_agent": "10-执行-产品专家"}
        next_targets = _normalize_target_list(retained_status.get("next_10_writable_targets"))
        if next_targets:
            dispatch_request["writable_targets"] = next_targets
        return _dispatch_via_resolver(
            project_root,
            runtime_root,
            action=action,
            authority_snapshot=authority_snapshot,
            latest_status={},
            dispatch_intent="product_source_completion",
            dispatch_request=dispatch_request,
        )
    if _retained_10_no_primary_next_hop(retained_status) and retained_status.get("return_reason") == "blocked":
        return _dispatch_via_resolver(
            project_root,
            runtime_root,
            action=action,
            authority_snapshot=_build_authority_snapshot(
                latest_delivery.payload,
                dispatch_instance_id=_new_dispatch_instance_id("01"),
                retained_status=retained_status,
            ),
            latest_status={},
            dispatch_intent="project_package_initialization",
            dispatch_request={
                "target_agent": "01-编排-初始化项目包",
            },
        )
    if _retained_receipt_waits_for_user_intent(retained_status):
        return _no_primary_window_dispatch_pending_payload(action=action)
    retained_status_for_01 = (
        retained_status
        if _retained_receipt_allows_01_structure_repair(retained_status)
        or _retained_01_execution_structure_blocker(retained_status)
        else None
    )
    return _dispatch_via_resolver(
        project_root,
        runtime_root,
        action=action,
        authority_snapshot=_build_authority_snapshot(
            latest_delivery.payload,
            dispatch_instance_id=_new_dispatch_instance_id("01"),
            retained_status=retained_status_for_01,
        ),
        latest_status={},
        dispatch_intent="project_package_initialization",
        dispatch_request={
            "target_agent": "01-编排-初始化项目包",
        },
    )


def _handle_read_receipt(project_root: Path, runtime_root: Path, *, receipt_carrier: str) -> dict[str, Any]:
    carrier = _ensure_authority_carrier(project_root)
    latest_delivery = carrier.latest_delivery_owner
    snapshot_record = carrier.latest_dispatch_snapshot
    if latest_delivery is None or snapshot_record is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": "missing active primary-window dispatch snapshot for /读取回执",
            }
        )
    active_snapshot = snapshot_record.payload
    current_agent = str(active_snapshot.get("target_agent") or "").strip()
    if current_agent not in PRIMARY_WINDOW_AGENTS:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": "latest dispatch snapshot is not a primary-window agent",
            }
        )
    authority_snapshot = _build_authority_snapshot_from_active_dispatch(
        latest_delivery.payload,
        active_snapshot,
    )
    validation_payload = _run_json_helper(
        runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "validate_primary_window_receipt.py",
        {
            "authority_snapshot": authority_snapshot,
            "receipt_carrier": receipt_carrier,
            "project_root": str(project_root.resolve()),
        },
        project_root=project_root,
    )
    if validation_payload.get("ok") is not True:
        raise RuntimeEntryError(payload=_wrap_helper_failure("read_receipt", validation_payload))
    retained_status = _extract_retained_latest_status(latest_delivery.payload)
    consume_payload = _run_json_helper(
        runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "consume_total_control_receipt.py",
        {
            "validated_receipt": validation_payload["result"]["validated_receipt"],
            "authority_snapshot": authority_snapshot,
            "latest_receipt_consumption_status": retained_status,
        },
        project_root=project_root,
    )
    if consume_payload.get("ok") is not True:
        raise RuntimeEntryError(payload=_wrap_helper_failure("read_receipt", consume_payload))
    if consume_payload.get("decision") != "receipt_consumed":
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": f"receipt was not consumed by helper: {consume_payload.get('decision')}",
                "errors": [str(consume_payload.get("decision") or "receipt_not_consumed")],
            }
        )
    canonical_consume_result = dict(consume_payload["result"]["canonical_consume_result"])
    if canonical_consume_result.get("receipt_consumed") is not True:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": "receipt consume result did not authorize authority writeback",
                "errors": [str(consume_payload.get("decision") or "receipt_not_consumed")],
            }
        )
    target_agent = str(canonical_consume_result.get("recommended_return_target") or "").strip()
    if target_agent != NO_PRIMARY_WINDOW_NEXT_HOP and target_agent not in PRIMARY_WINDOW_AGENTS:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": f"unsupported recommended_return_target for runtime receipt reopen: {target_agent or 'missing'}",
            }
        )
    updated_delivery_payload = dict(latest_delivery.payload)
    updated_delivery_payload.update(_consume_result_to_retained_fields(canonical_consume_result))
    _rewrite_latest_delivery_owner(project_root, latest_delivery, updated_delivery_payload)
    authority_writeback = _authority_writeback_evidence(project_root)
    if target_agent == NO_PRIMARY_WINDOW_NEXT_HOP:
        release_evidence = _project_release_evidence(project_root)
        return {
            "ok": True,
            "action": "read_receipt",
            "decision": "receipt_consumed",
            **release_evidence,
            "project_root": str(project_root.resolve()),
            "authority_path": AUTHORITY_HOST.as_posix(),
            "authority_writeback": authority_writeback,
            "dispatch_target": None,
            "prompt_text": None,
            "fixed_user_reply": (
                "已读取并消费子线程回执；当前没有要立即派发的 primary-window 子线程。"
                "请由 00 按用户最新意图重新判断下一步。"
            ),
            "authority_host": AUTHORITY_HOST.as_posix(),
            "next_required_action": "total_control_rejudge",
            "canonical_consume_result": canonical_consume_result,
        }
    refresh_carrier = _ensure_authority_carrier(project_root)
    refresh_delivery = refresh_carrier.latest_delivery_owner
    if refresh_delivery is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "authority_blocked",
                "summary": "authority carrier lost Delivery Owner Record after receipt consume",
            }
        )
    refreshed_retained = _extract_retained_latest_status(refresh_delivery.payload)
    dispatch_intent = PRIMARY_WINDOW_AGENTS[target_agent]
    next_dispatch_prefix = target_agent.split("-", 1)[0] if "-" in target_agent else "next"
    authority_for_rejudge = _build_authority_snapshot(
        refresh_delivery.payload,
        dispatch_instance_id=_new_dispatch_instance_id(next_dispatch_prefix),
        retained_status=refreshed_retained,
    )
    dispatch_request: dict[str, Any] = {"target_agent": target_agent}
    next_targets = _normalize_target_list(canonical_consume_result.get("next_10_writable_targets"))
    if target_agent == "10-执行-产品专家" and next_targets:
        dispatch_request["writable_targets"] = next_targets
    receipt_handoff_input = _build_receipt_replay_input_package(canonical_consume_result)
    if receipt_handoff_input:
        dispatch_request["input_package"] = receipt_handoff_input
    return _dispatch_via_resolver(
        project_root,
        runtime_root,
        action="read_receipt",
        authority_snapshot=authority_for_rejudge,
        latest_status={},
        dispatch_intent=dispatch_intent,
        dispatch_request=dispatch_request,
    )


def _dispatch_via_resolver(
    project_root: Path,
    runtime_root: Path,
    *,
    action: str,
    authority_snapshot: dict[str, Any],
    latest_status: dict[str, Any],
    dispatch_intent: str,
    dispatch_request: dict[str, Any],
) -> dict[str, Any]:
    dispatch_request = _enrich_project_package_dispatch_request(
        runtime_root,
        dispatch_intent=dispatch_intent,
        dispatch_request=dispatch_request,
    )
    resolver_payload = _run_json_helper(
        runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "resolve_route_and_window_state.py",
        {
            "authority_snapshot": authority_snapshot,
            "latest_consumed_receipt_status": latest_status,
            "dispatch_intent": dispatch_intent,
            "dispatch_request": dispatch_request,
        },
        project_root=project_root,
    )
    if resolver_payload.get("ok") is not True:
        raise RuntimeEntryError(payload=_wrap_helper_failure(action, resolver_payload))
    resolver_result = dict(resolver_payload["result"])
    if resolver_result.get("dispatch_allowed") is not True:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": action,
                "decision": str(resolver_payload.get("decision") or "dispatch_blocked"),
                "summary": "resolver did not authorize dispatch",
                "route_result": resolver_result,
                "errors": resolver_payload.get("errors", []),
            }
        )
    handoff_spec = dict(resolver_result["closed_handoff_spec"])
    prompt_result = _run_prompt_builder(runtime_root, handoff_spec=handoff_spec, project_root=project_root)
    dispatch_prompt_path = _write_host_native_dispatch_prompt(
        project_root,
        handoff_spec=handoff_spec,
        dispatch_prompt=prompt_result.dispatch_prompt,
    )
    dispatch_prompt_sha256 = hashlib.sha256(prompt_result.dispatch_prompt.encode("utf-8")).hexdigest()
    contract_artifact = _write_dispatch_input_contract_artifact(
        project_root,
        handoff_spec=handoff_spec,
        dispatch_prompt=prompt_result.dispatch_prompt,
        dispatch_prompt_path=dispatch_prompt_path,
        dispatch_prompt_sha256=dispatch_prompt_sha256,
    )
    snapshot_payload = _snapshot_payload_from_handoff_spec(
        handoff_spec,
        role_prompt_sha256=prompt_result.role_prompt_sha256,
        dispatch_prompt_path=dispatch_prompt_path,
        dispatch_prompt_sha256=dispatch_prompt_sha256,
        dispatch_input_contract_path=contract_artifact.path,
        dispatch_input_contract_sha256=contract_artifact.sha256,
    )
    _append_dispatch_snapshot(project_root, snapshot_payload)
    target_agent = str(handoff_spec["agent"])
    return {
        "ok": True,
        "action": action,
        "decision": str(resolver_payload.get("decision") or "dispatch_allowed"),
        "dispatch_target": target_agent,
        "prompt_text": None,
        "fixed_user_reply": (
            f"当前已判定应派发 `{target_agent}`；必须调用 Codex `spawn_agent` "
            f"并让子 agent 读取 `{dispatch_prompt_path}`，不得在当前 root 线程代演。"
        ),
        "host_native_dispatch": _host_native_dispatch_payload(
            project_root=project_root,
            target_agent=target_agent,
            dispatch_prompt_path=dispatch_prompt_path,
            dispatch_prompt_sha256=dispatch_prompt_sha256,
            dispatch_input_contract_path=contract_artifact.path,
            dispatch_input_contract_sha256=contract_artifact.sha256,
        ),
        "authority_host": AUTHORITY_HOST.as_posix(),
        "route_result": resolver_result,
    }


def _enrich_project_package_dispatch_request(
    runtime_root: Path,
    *,
    dispatch_intent: str,
    dispatch_request: dict[str, Any],
) -> dict[str, Any]:
    if dispatch_intent != "project_package_initialization":
        return dispatch_request
    enriched = dict(dispatch_request)
    if _normalize_target_list(enriched.get("formal_writable_targets")):
        return enriched
    formal_targets = _load_project_package_formal_targets(runtime_root)
    if formal_targets:
        enriched["formal_writable_targets"] = formal_targets
    return enriched


def _load_project_package_formal_targets(runtime_root: Path) -> list[str]:
    payload = safe_read_json(runtime_root / "assets" / "contracts" / "project_package_formal_targets.json")
    if not isinstance(payload, dict):
        return []
    targets = payload.get("targets")
    if not isinstance(targets, list):
        return []
    normalized: list[str] = []
    for entry in targets:
        if not isinstance(entry, dict):
            continue
        target = entry.get("project_target")
        if isinstance(target, str) and target.strip():
            normalized.append(target.strip())
    return normalized


def _load_runtime_root(project_root: Path) -> Path:
    payload = safe_read_json(project_root / ".ai-team" / "runtime.json")
    if not isinstance(payload, dict):
        raise RuntimeEntryError(
            payload=_runtime_missing_payload(
                project_root,
                summary=".ai-team/runtime.json is missing or unreadable",
                project_runtime_state="missing",
            )
        )
    bundle_root = payload.get("bundle_root")
    if not isinstance(bundle_root, str) or not bundle_root.strip():
        raise RuntimeEntryError(
            payload=_runtime_missing_payload(
                project_root,
                summary=".ai-team/runtime.json is missing bundle_root",
                project_runtime_state="blocked",
            )
        )
    runtime_root = Path(bundle_root).expanduser().resolve()
    if not runtime_root.exists():
        raise RuntimeEntryError(
            payload={
                **_runtime_missing_payload(
                    project_root,
                    summary="runtime bundle root does not exist",
                    project_runtime_state="blocked",
                ),
                "bundle_root": str(runtime_root),
            }
        )
    return runtime_root


def _runtime_missing_payload(
    project_root: Path,
    *,
    summary: str,
    project_runtime_state: str,
) -> dict[str, object]:
    return {
        "ok": False,
        "action": "runtime_bootstrap",
        "decision": "runtime_missing",
        "reason_code": "runtime_missing",
        "failure_category": "project_runtime",
        "blocked_stage": "项目运行时",
        "summary": summary,
        "project_root": str(project_root),
        "machine_state": "unknown",
        "project_runtime_state": project_runtime_state,
        "total_control_state": "blocked",
        "recommended_action": f"run `ai-team install --project-root {project_root}` before entering /总控",
        "next_step": f"在项目根目录重新运行 ai-team install --project-root {project_root} 或 repair。",
    }


def _resolve_receipt_text(project_root: Path, *, receipt_file: str | None, receipt_text: str | None) -> str:
    if receipt_text:
        return receipt_text
    if receipt_file:
        path = Path(receipt_file)
        if not path.is_absolute():
            path = (project_root / path).resolve()
        try:
            return _extract_latest_terminal_receipt(path.read_text(encoding="utf-8"))
        except OSError as exc:
            raise RuntimeEntryError(
                payload={
                    "ok": False,
                    "action": "read_receipt",
                    "decision": "schema_error",
                    "summary": f"receipt file could not be read: {exc}",
                },
                exit_code=2,
            ) from exc
    raise RuntimeEntryError(
        payload={
            "ok": False,
            "action": "read_receipt",
            "decision": "schema_error",
            "summary": "read_receipt requires --receipt-file or --receipt-text",
        },
        exit_code=2,
    )


def _extract_latest_terminal_receipt(receipt_file_text: str) -> str:
    terminal_blocks = list(TERMINAL_RECEIPT_PATTERN.finditer(receipt_file_text))
    if not terminal_blocks:
        return receipt_file_text
    active_dispatch_id = _extract_latest_dispatch_snapshot_id(receipt_file_text)
    if active_dispatch_id:
        for block in reversed(terminal_blocks):
            body = block.group("body")
            if _receipt_body_dispatch_instance_id(body) == active_dispatch_id:
                return body.strip() + "\n"
    return terminal_blocks[-1].group("body").strip() + "\n"


def _extract_latest_dispatch_snapshot_id(receipt_file_text: str) -> str | None:
    latest_dispatch_id: str | None = None
    for match in RECORD_PATTERN.finditer(receipt_file_text):
        if match.group("label") == "Dispatch Snapshot Record":
            latest_dispatch_id = match.group("identifier").strip()
    return latest_dispatch_id


def _receipt_body_dispatch_instance_id(receipt_body: str) -> str | None:
    match = re.search(r"^- dispatch_instance_id[：:](?P<value>[^\n]+)$", receipt_body, re.MULTILINE)
    if not match:
        return None
    return match.group("value").strip()


def _run_json_helper(script_path: Path, payload: dict[str, Any], *, project_root: Path) -> dict[str, Any]:
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".json", delete=False) as tmp:
        tmp_path = Path(tmp.name)
        tmp.write(json.dumps(payload, ensure_ascii=False, indent=2))
    try:
        env = _build_runtime_subprocess_env()
        result = subprocess.run(
            [sys.executable, str(script_path), "--input-json", str(tmp_path)],
            cwd=project_root,
            env=env,
            capture_output=True,
            text=False,
            check=False,
        )
    finally:
        tmp_path.unlink(missing_ok=True)
    stdout = _decode_runtime_subprocess_stream(result.stdout)
    stderr = _decode_runtime_subprocess_stream(result.stderr)
    try:
        output = json.loads(stdout.strip() or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "runtime_helper",
                "decision": "runtime_error",
                "summary": f"helper emitted non-JSON stdout: {script_path.name}",
                "stderr": stderr,
                "stdout": stdout,
            }
        ) from exc
    if not isinstance(output, dict):
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "runtime_helper",
                "decision": "runtime_error",
                "summary": f"helper emitted non-mapping verdict: {script_path.name}",
                "stderr": stderr,
                "stdout": stdout,
            }
        )
    return output


def _run_prompt_builder(runtime_root: Path, *, handoff_spec: dict[str, Any], project_root: Path) -> PromptBuilderResult:
    builder_path = runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "build_dispatch_prompt.py"
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".json", delete=False) as tmp:
        tmp_path = Path(tmp.name)
        tmp.write(json.dumps(handoff_spec, ensure_ascii=False, indent=2))
    try:
        env = _build_runtime_subprocess_env()
        result = subprocess.run(
            [sys.executable, str(builder_path), "--handoff-spec", str(tmp_path)],
            cwd=project_root,
            env=env,
            capture_output=True,
            text=False,
            check=False,
        )
    finally:
        tmp_path.unlink(missing_ok=True)
    stdout = _decode_runtime_subprocess_stream(result.stdout)
    stderr = _decode_runtime_subprocess_stream(result.stderr)
    if result.returncode != 0:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "build_dispatch_prompt",
                "decision": "runtime_error",
                "summary": "build_dispatch_prompt failed",
                "stderr": stderr.strip(),
            }
        )
    try:
        output = json.loads(stdout.strip() or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "build_dispatch_prompt",
                "decision": "runtime_error",
                "summary": "build_dispatch_prompt emitted non-JSON stdout",
                "stderr": stderr.strip(),
                "stdout": stdout,
            }
        ) from exc
    if not isinstance(output, dict):
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "build_dispatch_prompt",
                "decision": "runtime_error",
                "summary": "build_dispatch_prompt emitted non-mapping payload",
                "stderr": stderr.strip(),
                "stdout": stdout,
            }
        )
    dispatch_prompt = output.get("dispatch_prompt")
    if not isinstance(dispatch_prompt, str) or not dispatch_prompt.strip():
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "build_dispatch_prompt",
                "decision": "runtime_error",
                "summary": "build_dispatch_prompt returned empty dispatch_prompt",
                "stderr": stderr.strip(),
                "stdout": stdout,
            }
        )
    role_prompt_sha256 = output.get("role_prompt_sha256")
    if isinstance(role_prompt_sha256, str):
        role_prompt_sha256 = role_prompt_sha256.strip() or None
    else:
        role_prompt_sha256 = None
    return PromptBuilderResult(
        dispatch_prompt=dispatch_prompt,
        role_prompt_sha256=role_prompt_sha256,
    )


def _ensure_authority_carrier(project_root: Path) -> AuthorityCarrierState:
    path = project_root / AUTHORITY_HOST
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_bootstrap_authority_carrier_text(), encoding="utf-8")
    text = path.read_text(encoding="utf-8")
    records: list[StructuredRecord] = []
    for match in RECORD_PATTERN.finditer(text):
        payload = yaml.safe_load(match.group("payload")) or {}
        if not isinstance(payload, dict):
            payload = {}
        records.append(
            StructuredRecord(
                label=match.group("label"),
                identifier=match.group("identifier").strip(),
                payload=dict(payload),
                start=match.start(),
                end=match.end(),
            )
        )
    return AuthorityCarrierState(path=path, text=text, records=records)


def _build_runtime_subprocess_env() -> dict[str, str]:
    env = os.environ.copy()
    launcher_src_root = str(Path(__file__).resolve().parents[1])
    existing_pythonpath = env.get("PYTHONPATH", "").strip()
    pythonpath_parts = [launcher_src_root]
    if existing_pythonpath:
        pythonpath_parts.append(existing_pythonpath)
    env["PYTHONPATH"] = os.pathsep.join(pythonpath_parts)
    env["PYTHONIOENCODING"] = "utf-8"
    return env


def _decode_runtime_subprocess_stream(raw: bytes | str | None) -> str:
    if raw is None:
        return ""
    if isinstance(raw, str):
        return raw
    for encoding in ("utf-8", locale.getpreferredencoding(False), sys.getfilesystemencoding()):
        if not encoding:
            continue
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _bootstrap_authority_carrier_text() -> str:
    payload = {
        "schema": "total_control.delivery_owner_record.v1",
        "task_chain_id": "tc-runtime-entry-bootstrap",
        "task_chain_epoch": 1,
        "authority_record_version": 1,
        "scope_level": "project",
        "scope_path": "00-项目包/04-过程文件/00-沟通记录与结论回写.md",
        "当前责任模式": "standard",
        "模式来源": "runtime_entry_bootstrap",
        "二次握手结果": "confirmed",
        "锁存范围": "runtime_entry_scope",
        "退出条件": "control_receipt_consumed",
        "当前状态": "standard",
    }
    return "# 沟通记录与结论回写\n\n" + _render_record(
        label="Delivery Owner Record",
        identifier="tc-runtime-entry-bootstrap#1",
        payload=payload,
    )


def _render_record(*, label: str, identifier: str, payload: dict[str, Any]) -> str:
    yaml_text = yaml.safe_dump(payload, allow_unicode=True, sort_keys=False).rstrip()
    return f"### {label} {identifier}\n```yaml\n{yaml_text}\n```\n"


def _rewrite_latest_delivery_owner(project_root: Path, record: StructuredRecord, payload: dict[str, Any]) -> None:
    carrier = _ensure_authority_carrier(project_root)
    refreshed_record = carrier.latest_delivery_owner
    if refreshed_record is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "authority_writeback",
                "decision": "authority_blocked",
                "summary": "authority carrier is missing Delivery Owner Record",
            }
        )
    new_block = _render_record(label=refreshed_record.label, identifier=refreshed_record.identifier, payload=payload)
    updated_text = carrier.text[: refreshed_record.start] + new_block + carrier.text[refreshed_record.end :]
    carrier.path.write_text(updated_text, encoding="utf-8")


def _project_release_evidence(project_root: Path) -> dict[str, Any]:
    runtime_payload = safe_read_json(project_root / ".ai-team" / "runtime.json") or {}
    lock_payload = safe_read_json(project_root / "ai-team.lock.json") or {}
    bundle_version = runtime_payload.get("bundle_version") or lock_payload.get("bundle_version")
    release_tag = runtime_payload.get("release_tag")
    bundle_sha256 = runtime_payload.get("bundle_sha256") or lock_payload.get("bundle_sha256")
    return {
        "bundle_version": bundle_version,
        "release_tag": release_tag,
        "bundle_sha256": bundle_sha256,
    }


def _authority_writeback_evidence(project_root: Path) -> dict[str, Any]:
    authority_path = project_root / AUTHORITY_HOST
    try:
        authority_text = authority_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "authority_writeback",
                "decision": "authority_blocked",
                "summary": f"authority carrier could not be read after writeback: {exc}",
            }
        ) from exc
    return {
        "ok": True,
        "path": AUTHORITY_HOST.as_posix(),
        "sha256": hashlib.sha256(authority_text.encode("utf-8")).hexdigest(),
        "retained_status": "updated",
    }


def _append_dispatch_snapshot(project_root: Path, payload: dict[str, Any]) -> None:
    carrier = _ensure_authority_carrier(project_root)
    append_block = _render_record(
        label="Dispatch Snapshot Record",
        identifier=str(payload["dispatch_instance_id"]),
        payload=payload,
    )
    stripped = carrier.text.rstrip()
    separator = "\n\n" if stripped else ""
    carrier.path.write_text(stripped + separator + append_block, encoding="utf-8")


def _extract_retained_latest_status(delivery_payload: dict[str, Any]) -> dict[str, Any]:
    retained: dict[str, Any] = {}
    for source_key, target_key in AUTHORITY_REPLAY_RETENTION_FIELD_MAP.items():
        if source_key not in delivery_payload:
            continue
        value = delivery_payload[source_key]
        if target_key == "receipt_consumed":
            retained[target_key] = _parse_boolish(value)
        else:
            retained[target_key] = value
    return retained


def _normalize_target_list(value: object) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return []
        return [part.strip() for part in re.split(r"[|,，]\s*", stripped) if part.strip()]
    return []


def _retained_receipt_reopens_10(retained_status: dict[str, Any]) -> bool:
    required = [
        retained_status.get("receipt_consumed") is True,
        retained_status.get("child_thread") == "01-编排-初始化项目包",
        retained_status.get("return_reason") == "completed",
        retained_status.get("recommended_return_target") == "10-执行-产品专家",
        retained_status.get("delivery_mode_explicit") is True,
        retained_status.get("active_module_set_explicit") is True,
        retained_status.get("module_structure_ready") is True,
        retained_status.get("writable_targets_ready") is True,
        bool(_normalize_target_list(retained_status.get("next_10_writable_targets"))),
    ]
    return all(required)


def _missing_execution_structure_fields(retained_status: dict[str, Any]) -> list[str]:
    missing = [
        field_name
        for field_name in EXECUTION_STRUCTURE_BOOLEAN_FIELDS
        if retained_status.get(field_name) is not True
    ]
    if not _normalize_target_list(retained_status.get("next_10_writable_targets")):
        missing.append("next_10_writable_targets")
    return missing


def _retained_01_execution_structure_blocker(retained_status: dict[str, Any]) -> bool:
    return (
        retained_status.get("receipt_consumed") is True
        and retained_status.get("child_thread") == "01-编排-初始化项目包"
        and retained_status.get("return_reason") == "blocked"
        and retained_status.get("recommended_return_target") == NO_PRIMARY_WINDOW_NEXT_HOP
        and retained_status.get("project_package_ready") is True
        and not _normalize_target_list(retained_status.get("formal_targets_missing"))
        and bool(_missing_execution_structure_fields(retained_status))
    )


def _retained_10_no_primary_next_hop(retained_status: dict[str, Any]) -> bool:
    return (
        retained_status.get("receipt_consumed") is True
        and retained_status.get("child_thread") == "10-执行-产品专家"
        and retained_status.get("recommended_return_target") == NO_PRIMARY_WINDOW_NEXT_HOP
    )


def _retained_receipt_allows_01_structure_repair(retained_status: dict[str, Any]) -> bool:
    return (
        _retained_10_no_primary_next_hop(retained_status)
        and retained_status.get("return_reason") == "blocked"
        and retained_status.get("structure_blocker_owner") == STRUCTURE_BLOCKER_OWNER
        and retained_status.get("structure_blocker_code") in STRUCTURE_BLOCKER_CODES
    )


def _retained_receipt_waits_for_user_intent(retained_status: dict[str, Any]) -> bool:
    if not _retained_10_no_primary_next_hop(retained_status):
        return False
    return not _retained_receipt_allows_01_structure_repair(retained_status)


def _no_primary_window_dispatch_pending_payload(*, action: str) -> dict[str, Any]:
    return {
        "ok": True,
        "action": action,
        "decision": "no_primary_window_dispatch_pending",
        "dispatch_target": None,
        "prompt_text": None,
        "fixed_user_reply": "当前没有要立即派发的 primary-window 子线程，请按用户最新意图重新判断下一步。",
        "authority_host": AUTHORITY_HOST.as_posix(),
        "next_required_action": "await_user_next_intent",
        "authority_writeback": False,
    }


def _build_authority_snapshot_from_active_dispatch(
    delivery_payload: dict[str, Any],
    active_snapshot: dict[str, Any],
) -> dict[str, Any]:
    errors: list[str] = []
    for field_name in ("dispatch_instance_id", "task_chain_id", "task_chain_epoch", "target_agent"):
        if active_snapshot.get(field_name) in (None, ""):
            errors.append(f"missing active dispatch snapshot field: {field_name}")
    delivery_task_chain_id = str(delivery_payload.get("task_chain_id") or "").strip()
    delivery_task_chain_epoch = str(delivery_payload.get("task_chain_epoch") or "").strip()
    snapshot_task_chain_id = str(active_snapshot.get("task_chain_id") or "").strip()
    snapshot_task_chain_epoch = str(active_snapshot.get("task_chain_epoch") or "").strip()
    if delivery_task_chain_id and snapshot_task_chain_id and delivery_task_chain_id != snapshot_task_chain_id:
        errors.append("dispatch snapshot does not match Delivery Owner Record: task_chain_id")
    if delivery_task_chain_epoch and snapshot_task_chain_epoch and delivery_task_chain_epoch != snapshot_task_chain_epoch:
        errors.append("dispatch snapshot does not match Delivery Owner Record: task_chain_epoch")
    if errors:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": "dispatch snapshot does not match Delivery Owner Record",
                "errors": errors,
            }
        )
    return {
        "dispatch_instance_id": str(active_snapshot["dispatch_instance_id"]),
        "task_chain_id": snapshot_task_chain_id,
        "task_chain_epoch": int(active_snapshot["task_chain_epoch"]),
        "target_agent": str(active_snapshot["target_agent"]),
    }


def _build_authority_snapshot(
    delivery_payload: dict[str, Any],
    *,
    dispatch_instance_id: str,
    retained_status: dict[str, Any] | None = None,
) -> dict[str, Any]:
    snapshot = {
        "dispatch_instance_id": dispatch_instance_id,
        "task_chain_id": str(delivery_payload.get("task_chain_id") or "tc-runtime-entry-bootstrap"),
        "task_chain_epoch": int(delivery_payload.get("task_chain_epoch") or 1),
    }
    retained_status = retained_status or {}
    reverse_field_map = {status_key: authority_key for authority_key, status_key in AUTHORITY_REPLAY_RETENTION_FIELD_MAP.items()}
    for status_key, authority_key in reverse_field_map.items():
        if status_key not in retained_status:
            continue
        snapshot[authority_key] = retained_status[status_key]
    return snapshot


def _consume_result_to_retained_fields(canonical_consume_result: dict[str, Any]) -> dict[str, Any]:
    field_map = {status_key: authority_key for authority_key, status_key in AUTHORITY_REPLAY_RETENTION_FIELD_MAP.items()}
    retained_fields: dict[str, Any] = {}
    for source_key, target_key in field_map.items():
        if source_key not in canonical_consume_result:
            continue
        retained_fields[target_key] = canonical_consume_result[source_key]
    return retained_fields


def _build_receipt_replay_input_package(canonical_consume_result: dict[str, Any]) -> dict[str, Any]:
    input_package: dict[str, Any] = {
        "goal": "Continue product source completion after 01 receipt consumption.",
        "source": "runtime_entry.read_receipt",
    }
    for field_name in CR004_RECEIPT_HANDOFF_FIELDS:
        if field_name not in canonical_consume_result:
            continue
        input_package[field_name] = canonical_consume_result[field_name]
    if set(input_package) == {"goal", "source"}:
        return {}
    return input_package


def _snapshot_payload_from_handoff_spec(
    handoff_spec: dict[str, Any],
    *,
    role_prompt_sha256: str | None,
    dispatch_prompt_path: str | None,
    dispatch_prompt_sha256: str | None,
    dispatch_input_contract_path: str | None,
    dispatch_input_contract_sha256: str | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "schema": "total_control.dispatch_snapshot_record.v1",
        "dispatch_schema_version": 1,
        "dispatch_instance_id": handoff_spec["dispatch_instance_id"],
        "task_chain_id": handoff_spec["task_chain_id"],
        "task_chain_epoch": handoff_spec["task_chain_epoch"],
        "target_agent": handoff_spec["agent"],
        "role_prompt_source": handoff_spec["role_prompt_source"],
        "writable_targets": handoff_spec["writable_targets"],
        "allow_direct_user_question": handoff_spec["allow_direct_user_question"],
        "allowed_user_question_scope": handoff_spec["allowed_user_question_scope"],
        "input_package": handoff_spec["input_package"],
        "dispatch_intent": handoff_spec["dispatch_intent"],
        "host_dispatch_mode": "codex_spawn_agent",
    }
    if isinstance(dispatch_prompt_path, str) and dispatch_prompt_path.strip():
        payload["dispatch_prompt_path"] = dispatch_prompt_path.strip()
    if isinstance(dispatch_prompt_sha256, str) and dispatch_prompt_sha256.strip():
        payload["dispatch_prompt_sha256"] = dispatch_prompt_sha256.strip()
    if isinstance(dispatch_input_contract_path, str) and dispatch_input_contract_path.strip():
        payload["dispatch_input_contract_path"] = dispatch_input_contract_path.strip()
    if isinstance(dispatch_input_contract_sha256, str) and dispatch_input_contract_sha256.strip():
        payload["dispatch_input_contract_sha256"] = dispatch_input_contract_sha256.strip()
    for optional_key in ("dod", "receipt_contract", "blocker_scope"):
        if optional_key in handoff_spec:
            payload[optional_key] = handoff_spec[optional_key]
    if "formal_writable_targets" in handoff_spec:
        payload["formal_writable_targets"] = handoff_spec["formal_writable_targets"]
    if isinstance(role_prompt_sha256, str) and role_prompt_sha256.strip():
        payload["role_prompt_sha256"] = role_prompt_sha256.strip()
    return payload


def _write_host_native_dispatch_prompt(
    project_root: Path,
    *,
    handoff_spec: dict[str, Any],
    dispatch_prompt: str,
) -> str:
    dispatch_instance_id = str(handoff_spec["dispatch_instance_id"]).strip()
    safe_dispatch_id = re.sub(r"[^A-Za-z0-9_.-]+", "-", dispatch_instance_id).strip("-")
    safe_agent = re.sub(r"[^A-Za-z0-9_.-]+", "-", str(handoff_spec.get("agent") or "").strip()).strip("-")
    prompt_sha256 = hashlib.sha256(dispatch_prompt.encode("utf-8")).hexdigest()
    if not safe_dispatch_id:
        safe_dispatch_id = "dispatch"
    if not safe_agent:
        safe_agent = "agent"
    relative_path = (
        Path(".ai-team")
        / "state"
        / "dispatch-prompts"
        / f"{safe_dispatch_id}-{safe_agent}-{prompt_sha256[:16]}.md"
    )
    prompt_path = project_root / relative_path
    prompt_path.parent.mkdir(parents=True, exist_ok=True)
    if prompt_path.exists() and prompt_path.read_text(encoding="utf-8") != dispatch_prompt:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "host_native_dispatch",
                "decision": "dispatch_prompt_collision",
                "summary": f"dispatch prompt path collision: {relative_path.as_posix()}",
            }
        )
    prompt_path.write_text(dispatch_prompt, encoding="utf-8")
    return relative_path.as_posix()


def _write_dispatch_input_contract_artifact(
    project_root: Path,
    *,
    handoff_spec: dict[str, Any],
    dispatch_prompt: str,
    dispatch_prompt_path: str,
    dispatch_prompt_sha256: str,
) -> DispatchInputContractArtifact:
    dispatch_contract_block = _extract_dispatch_contract_block(dispatch_prompt)
    dispatch_input_contract = dispatch_contract_block.get("dispatch_input_contract")
    if not isinstance(dispatch_input_contract, dict):
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "host_native_dispatch",
                "decision": "dispatch_input_contract_missing",
                "summary": "dispatch prompt did not materialize dispatch_input_contract",
            }
        )
    artifact_payload = {
        "schema": "total_control.dispatch_input_contract_artifact.v1",
        "dispatch_instance_id": handoff_spec["dispatch_instance_id"],
        "task_chain_id": handoff_spec["task_chain_id"],
        "task_chain_epoch": handoff_spec["task_chain_epoch"],
        "target_agent": handoff_spec["agent"],
        "dispatch_intent": handoff_spec["dispatch_intent"],
        "dispatch_prompt_path": dispatch_prompt_path,
        "dispatch_prompt_sha256": dispatch_prompt_sha256,
        "role_prompt_source": dispatch_contract_block.get("role_prompt_source"),
        "role_prompt_sha256": dispatch_contract_block.get("role_prompt_sha256"),
        "dispatch_input_contract": dispatch_input_contract,
        "dispatch_contract_block": dispatch_contract_block,
    }
    artifact_text = json.dumps(artifact_payload, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    artifact_sha256 = hashlib.sha256(artifact_text.encode("utf-8")).hexdigest()
    dispatch_instance_id = str(handoff_spec["dispatch_instance_id"]).strip()
    safe_dispatch_id = re.sub(r"[^A-Za-z0-9_.-]+", "-", dispatch_instance_id).strip("-") or "dispatch"
    safe_agent = re.sub(r"[^A-Za-z0-9_.-]+", "-", str(handoff_spec.get("agent") or "").strip()).strip("-") or "agent"
    relative_path = (
        Path(".ai-team")
        / "state"
        / "dispatch-contracts"
        / f"{safe_dispatch_id}-{safe_agent}-{artifact_sha256[:16]}.json"
    )
    artifact_path = project_root / relative_path
    artifact_path.parent.mkdir(parents=True, exist_ok=True)
    if artifact_path.exists() and artifact_path.read_text(encoding="utf-8") != artifact_text:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "host_native_dispatch",
                "decision": "dispatch_input_contract_collision",
                "summary": f"dispatch input contract path collision: {relative_path.as_posix()}",
            }
        )
    artifact_path.write_text(artifact_text, encoding="utf-8")
    return DispatchInputContractArtifact(path=relative_path.as_posix(), sha256=artifact_sha256)


def _extract_dispatch_contract_block(dispatch_prompt: str) -> dict[str, Any]:
    match = re.search(
        r"^### Dispatch Contract Block\n```yaml\n(?P<payload>.*?)```",
        dispatch_prompt,
        re.MULTILINE | re.DOTALL,
    )
    if not match:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "host_native_dispatch",
                "decision": "dispatch_contract_block_missing",
                "summary": "dispatch prompt is missing Dispatch Contract Block",
            }
        )
    payload = yaml.safe_load(match.group("payload")) or {}
    if not isinstance(payload, dict):
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "host_native_dispatch",
                "decision": "dispatch_contract_block_invalid",
                "summary": "Dispatch Contract Block did not decode to mapping",
            }
        )
    return dict(payload)


def _host_native_dispatch_payload(
    *,
    project_root: Path,
    target_agent: str,
    dispatch_prompt_path: str,
    dispatch_prompt_sha256: str,
    dispatch_input_contract_path: str,
    dispatch_input_contract_sha256: str,
) -> dict[str, Any]:
    absolute_prompt_path = (project_root / dispatch_prompt_path).resolve()
    return {
        "dispatch_mechanism": "codex_spawn_agent",
        "required_tool": "spawn_agent",
        "agent": target_agent,
        "project_root": str(project_root.resolve()),
        "dispatch_prompt_path": dispatch_prompt_path,
        "dispatch_prompt_absolute_path": str(absolute_prompt_path),
        "dispatch_prompt_sha256": dispatch_prompt_sha256,
        "dispatch_input_contract_path": dispatch_input_contract_path,
        "dispatch_input_contract_sha256": dispatch_input_contract_sha256,
        "spawn_agent_message": (
            f"你现在接管 `{target_agent}`。项目根目录是 `{project_root.resolve()}`；"
            f"先读取 `{absolute_prompt_path}` 的完整内容，"
            "只按其中的 Dispatch Contract Block 与 Role Prompt Body 执行。"
        ),
        "session_evidence_required": [
            "response_item.function_call.name == spawn_agent",
            "matching spawn_agent function_call_output contains agent_id",
            f"spawn_agent.arguments contains {target_agent}",
            f"spawn_agent.arguments contains {dispatch_prompt_path}",
            f"spawn_agent.arguments contains {absolute_prompt_path}",
        ],
        "root_thread_forbidden": [
            "不得读取 child prompt 后在当前 root 线程输出 child opening",
            "不得把 dispatch_allowed + prompt_text 当作真实派发成功",
        ],
    }

def _wrap_helper_failure(action: str, payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": False,
        "action": action,
        "decision": payload.get("decision", "runtime_error"),
        "summary": f"helper returned fail-closed verdict: {payload.get('script', 'unknown helper')}",
        "helper_result": payload.get("result", {}),
        "errors": payload.get("errors", []),
    }


def _new_dispatch_instance_id(prefix: str) -> str:
    return f"dispatch-{prefix.lower()}-{uuid.uuid4().hex[:12]}"


def _parse_boolish(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes"}:
            return True
        if normalized in {"false", "0", "no"}:
            return False
    return bool(value)


def _install_runtime_ready_for_total_control(status_payload: dict[str, Any], runtime_root: Path) -> bool:
    if str(status_payload.get("overall_state") or "").strip() == "ready":
        return True
    blockers = status_payload.get("blockers")
    if blockers != ["active runtime record points to unexpected bundle root"]:
        return False
    runtime_source = status_payload.get("runtime_source")
    if not isinstance(runtime_source, dict):
        return False
    active_bundle_root = runtime_source.get("active_bundle_root")
    if not isinstance(active_bundle_root, str) or not active_bundle_root.strip():
        return False
    return Path(active_bundle_root).expanduser().resolve() == runtime_root.resolve()
