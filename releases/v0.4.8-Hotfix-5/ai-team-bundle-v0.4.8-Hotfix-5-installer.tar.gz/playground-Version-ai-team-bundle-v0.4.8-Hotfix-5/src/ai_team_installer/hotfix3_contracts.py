from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


DEV_ROOT = Path(__file__).resolve().parents[2]
FORMAL_TARGETS_PATH = (
    DEV_ROOT / "install" / "default_bundle" / "assets" / "contracts" / "project_package_formal_targets.json"
)
GREEN_WORDS = (
    "ok=true",
    "failed=[]",
    "现场验收通过",
    "验收通过",
    "release_full_chain_v2_verified",
)
DISPATCH_ALLOWED_LABELS = (
    "当前任务",
    "输入引用",
    "读写目标",
    "停止条件",
    "禁止事项",
    "最小机器回执要求",
)
DISPATCH_FORBIDDEN_PATTERNS = (
    re.compile(r"Hotfix-\d+", re.I),
    re.compile(r"历史"),
    re.compile(r"旧修复"),
    re.compile(r"补丁"),
    re.compile(r"长背景"),
)


def validate_dispatch_prompt_self_limit(prompt: str) -> dict[str, Any]:
    errors: list[str] = []
    text = str(prompt or "")
    for label in DISPATCH_ALLOWED_LABELS:
        if f"{label}：" not in text and f"{label}:" not in text:
            errors.append(f"missing_dispatch_slot:{label}")
    for pattern in DISPATCH_FORBIDDEN_PATTERNS:
        if pattern.search(text):
            errors.append("forbidden_dispatch_context")
            break
    return _verdict(errors)


def validate_project_package_receipt_targets(receipt: dict[str, Any]) -> dict[str, Any]:
    required = _formal_targets()
    written = _string_list(receipt.get("formal_targets_written"))
    existing = _string_list(receipt.get("formal_targets_existing"))
    proven = set(written + existing)
    missing = [target for target in required if target not in proven]
    errors: list[str] = []
    if missing:
        errors.append("formal_targets_not_proven_per_file")
    if any(target == "00-项目包/" or target == "00-项目包" for target in proven):
        errors.append("formal_targets_not_proven_per_file")
    if receipt.get("project_package_ready") is True and errors:
        errors.append("project_package_ready_without_target_level_proof")
    return {
        "ok": not errors,
        "errors": _dedupe(errors),
        "required_formal_targets": required,
        "proven_formal_targets": sorted(proven),
        "missing_formal_targets": missing,
    }


def classify_hotfix3_session_evidence(
    session_jsonl: Path | str,
    *,
    expected_session_id: str,
    expected_source_path: str,
) -> dict[str, Any]:
    path = Path(session_jsonl).expanduser()
    records, raw_text = _read_jsonl(path)
    session_id = _session_id(records) or expected_session_id
    source_path = _source_path(records) or expected_source_path
    spawn_calls = [
        record
        for record in records
        if _payload_type(record) == "function_call" and _payload_name(record) == "spawn_agent"
    ]
    spawn_call_ids = {_payload(record).get("call_id") for record in spawn_calls}
    has_agent_id = any(
        _payload_type(record) == "function_call_output"
        and _payload(record).get("call_id") in spawn_call_ids
        and _spawn_output_has_agent_id(_payload(record).get("output"))
        for record in records
    )
    has_child_prompt_read = bool(re.search(r"child[_ -]?prompt[_ -]?read|读取.*dispatch.*prompt", raw_text, re.I))
    green_word_seen = any(word in raw_text for word in GREEN_WORDS)
    errors: list[str] = []
    verdict = "not_live_chain_verified"
    if len(spawn_calls) == 0 and green_word_seen:
        verdict = "invalid_positive_evidence"
        errors.append("green_word_without_real_spawn_agent_pairing")
    elif len(spawn_calls) == 0:
        errors.append("missing_spawn_agent")
    if len(spawn_calls) > 0 and not has_agent_id:
        errors.append("missing_spawn_agent_output_agent_id")
    if len(spawn_calls) > 0 and not has_child_prompt_read:
        errors.append("missing_child_prompt_read")
    if session_id != expected_session_id:
        errors.append("session_id_mismatch")
    if source_path != expected_source_path:
        errors.append("source_path_mismatch")
    return {
        "ok": verdict != "invalid_positive_evidence" and not errors,
        "session_id": session_id,
        "source_path": source_path,
        "spawn_agent_call_count": len(spawn_calls),
        "has_spawn_agent_output_agent_id": has_agent_id,
        "has_child_prompt_read": has_child_prompt_read,
        "green_word_seen": green_word_seen,
        "verdict": verdict,
        "errors": _dedupe(errors),
    }


def validate_read_receipt_runtime_evidence(evidence: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    command = str(evidence.get("read_receipt_command") or "")
    output = evidence.get("read_receipt_output")
    if "ai-team runtime" not in command or "--action read_receipt" not in command:
        errors.append("read_receipt_must_use_ai_team_runtime_wrapper")
    if not isinstance(output, dict) or output.get("decision") != "receipt_consumed":
        errors.append("read_receipt_must_be_consumed")
    if isinstance(output, dict) and output.get("decision") == "receipt_consumed" and not (
        output.get("next_required_action")
        or output.get("next_dispatch_request")
        or output.get("dispatch_target")
    ):
        errors.append("read_receipt_missing_next_hop_or_wait_decision")
    return _verdict(errors)


def validate_candidate_release_gate(payload: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    candidate = payload.get("candidate")
    if not isinstance(candidate, dict):
        candidate = {}
    if candidate.get("source") != "pinned_candidate":
        errors.append("candidate_must_be_pinned_candidate")
    sha = candidate.get("sha256")
    if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{64}", sha):
        errors.append("candidate_sha256_required")
    platforms = payload.get("platforms")
    if not isinstance(platforms, dict):
        platforms = {}
    windows = platforms.get("Windows")
    if not isinstance(windows, dict):
        errors.append("windows_evidence_required")
    else:
        if windows.get("fresh") == "not_covered" or windows.get("update") == "not_covered":
            errors.append("windows_not_covered_release_blocked")
    decision = "candidate_gate_passed" if not errors else "candidate_rejected"
    if "windows_not_covered_release_blocked" in errors:
        decision = "test_design_allowed_but_release_blocked"
    return {"ok": not errors, "decision": decision, "errors": _dedupe(errors)}


def validate_known_failed_release_status(payload: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    if payload.get("field_status") == "postrelease_failed":
        clean_values = {"released", "stable", "safe_to_install", "clean_released"}
        observed = {
            str(payload.get("version_index_status") or ""),
            str(payload.get("current_status") or ""),
            str(payload.get("release_metadata_status") or ""),
        }
        if observed & clean_values:
            errors.append("known_failed_release_still_marked_clean_released")
    return _verdict(errors)


def _formal_targets() -> list[str]:
    try:
        payload = json.loads(FORMAL_TARGETS_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    targets = payload.get("targets")
    if not isinstance(targets, list):
        return []
    return [
        str(entry.get("project_target")).strip()
        for entry in targets
        if isinstance(entry, dict) and str(entry.get("project_target") or "").strip()
    ]


def _read_jsonl(path: Path) -> tuple[list[dict[str, Any]], str]:
    try:
        raw_text = path.read_text(encoding="utf-8")
    except OSError:
        return [], ""
    records: list[dict[str, Any]] = []
    for line in raw_text.splitlines():
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(record, dict):
            records.append(record)
    return records, raw_text


def _session_id(records: list[dict[str, Any]]) -> str | None:
    for record in records:
        value = record.get("id") or record.get("session_id")
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _source_path(records: list[dict[str, Any]]) -> str | None:
    for record in records:
        value = record.get("source_path")
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _payload(record: dict[str, Any]) -> dict[str, Any]:
    payload = record.get("payload")
    return payload if isinstance(payload, dict) else {}


def _payload_type(record: dict[str, Any]) -> str | None:
    value = _payload(record).get("type")
    return value if isinstance(value, str) else None


def _payload_name(record: dict[str, Any]) -> str | None:
    value = _payload(record).get("name")
    return value if isinstance(value, str) else None


def _spawn_output_has_agent_id(output: Any) -> bool:
    if isinstance(output, str):
        try:
            output = json.loads(output)
        except json.JSONDecodeError:
            return False
    if not isinstance(output, dict):
        return False
    agent_id = output.get("agent_id")
    return isinstance(agent_id, str) and bool(agent_id.strip())


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _verdict(errors: list[str]) -> dict[str, Any]:
    return {"ok": not errors, "errors": _dedupe(errors)}


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    deduped: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped
