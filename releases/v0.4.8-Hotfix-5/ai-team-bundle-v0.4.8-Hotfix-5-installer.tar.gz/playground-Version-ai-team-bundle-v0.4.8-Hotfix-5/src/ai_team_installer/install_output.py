from __future__ import annotations

import re
from typing import Any


HUMAN_ENTRY_COMMAND = "/总控 请接管当前项目，并授权派发子agent"

REASON_TO_FAILURE_CATEGORY = {
    "network_unavailable": "network",
    "network_error": "network",
    "release_metadata_missing": "metadata",
    "release_metadata_unreadable": "metadata",
    "release_metadata_invalid": "metadata",
    "release_metadata_untrusted": "metadata",
    "checksum_mismatch": "checksum",
    "installer_archive_checksum_mismatch": "checksum",
    "permission_denied": "permission",
    "methodology_source_repo_root_forbidden": "permission",
    "runtime_missing": "project_runtime",
    "project_runtime_missing": "project_runtime",
    "runtime_bundle_source_missing": "project_runtime",
    "runtime_materialization_failed": "project_runtime",
    "governance_script_diverged": "project_runtime",
    "unsupported_platform": "unsupported_platform",
    "downgrade_blocked": "project_runtime",
}
KNOWN_FAILURE_CATEGORIES = {
    "network",
    "metadata",
    "checksum",
    "permission",
    "project_runtime",
    "unsupported_platform",
    "unknown",
}

FORBIDDEN_HUMAN_OUTPUT_PATTERNS = (
    re.compile(r"https?://", re.I),
    re.compile(r"\b[a-f0-9]{64}\b", re.I),
    re.compile(r"release metadata:", re.I),
    re.compile(r"archive:", re.I),
    re.compile(r"launcher:", re.I),
    re.compile(r"installer_archive_sha256", re.I),
    re.compile(r"bundle_sha256", re.I),
    re.compile(r"prompt_source", re.I),
    re.compile(r"Traceback", re.I),
    re.compile(r"PowerShell.*Exception", re.I),
    re.compile(r"^\s*[{[]", re.M),
)


def failure_category_for_reason(reason_code: object) -> str:
    if not isinstance(reason_code, str) or not reason_code.strip():
        return "unknown"
    normalized = reason_code.strip()
    if normalized in KNOWN_FAILURE_CATEGORIES:
        return normalized
    return REASON_TO_FAILURE_CATEGORY.get(normalized, "unknown")


def _single_line(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def format_install_success(payload: dict[str, Any]) -> str:
    bundle_version = _single_line(payload.get("bundle_version") or "unknown")
    project_runtime_state = _single_line(payload.get("project_runtime_state"))
    if project_runtime_state != "ready":
        raise ValueError("install success output requires explicit project_runtime_state=ready")
    log_path = _single_line(payload.get("log_path") or payload.get("install_summary_path") or "")
    return "\n".join(
        [
            f"安装完成：ai-team {bundle_version} 已接入当前项目。",
            f"项目 runtime：{project_runtime_state}",
            "下一步：在项目根目录打开 Codex，输入：",
            HUMAN_ENTRY_COMMAND,
            f"日志：{log_path}",
        ]
    )


def format_install_failure(payload: dict[str, Any]) -> str:
    failure_category = _single_line(
        payload.get("failure_category")
        or failure_category_for_reason(payload.get("reason_code"))
        or "install_blocked"
    )
    reason = _single_line(
        payload.get("human_readable_reason")
        or payload.get("summary")
        or "安装执行链未完成。"
    )
    next_step = _single_line(
        payload.get("next_step")
        or payload.get("suggested_action")
        or _default_next_step(failure_category)
        or "查看日志确认原因后重新运行 ai-team install。"
    )
    log_path = _single_line(payload.get("log_path") or "")
    return "\n".join(
        [
            f"安装未完成：{failure_category}",
            f"原因：{reason}",
            f"下一步：{next_step}",
            f"日志：{log_path}",
        ]
    )


def _default_next_step(failure_category: str) -> str:
    if failure_category == "project_runtime":
        return "在项目根目录重新运行 ai-team install 或 repair。"
    if failure_category == "network":
        return "检查网络或内网发布地址后重试。"
    if failure_category == "metadata":
        return "检查安装入口或等待重新发布。"
    if failure_category == "checksum":
        return "停止使用当前安装包，等待重新发布后重试。"
    if failure_category == "permission":
        return "切换到有写权限的项目根目录后重试。"
    if failure_category == "unsupported_platform":
        return "切换到受支持的 macOS 或 Windows 环境。"
    return "查看日志确认原因后重新运行 ai-team install。"


def lint_human_install_output(text: str) -> list[str]:
    errors: list[str] = []
    for pattern in FORBIDDEN_HUMAN_OUTPUT_PATTERNS:
        if pattern.search(text):
            errors.append(f"human install output leaked forbidden pattern: {pattern.pattern}")
    if "安装完成：" in text:
        for required in ("项目 runtime：", "下一步：在项目根目录打开 Codex，输入：", HUMAN_ENTRY_COMMAND, "日志："):
            if required not in text:
                errors.append(f"success output missing required human field: {required}")
    if "安装未完成：" in text:
        for required in ("原因：", "下一步：", "日志："):
            if required not in text:
                errors.append(f"failure output missing required human field: {required}")
    return errors
