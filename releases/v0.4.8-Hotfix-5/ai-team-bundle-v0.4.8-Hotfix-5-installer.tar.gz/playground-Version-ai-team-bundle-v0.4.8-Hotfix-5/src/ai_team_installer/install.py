from __future__ import annotations

import hashlib
import os
import platform
import re
from importlib.util import module_from_spec, spec_from_file_location
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .machine_state import compare_bundle_versions, read_machine_install_state
from .probe import ensure_hidden_workspace_ignored, probe_structure
from .startup import extract_human_entry_command, render_startup_prompt, runtime_total_control_prompt_source
from .state import append_governance_event, read_json, safe_read_json, write_json
from .total_control_repair import TotalControlRepairBlockedError, repair_total_control_authority


REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_BUNDLE_ROOT = REPO_ROOT / "install" / "default_bundle"
LOCK_FILE_NAME = "ai-team.lock.json"
INSPECTION_LINK_NAME = ".ai-team-inspect"
INSPECTION_LINK_TARGET = Path(".ai-team") / "runtime" / "default_bundle"
MANAGED_SOURCE_PREFIX = "# AI_TEAM_MANAGED_SOURCE: "
MANAGED_SHA256_PREFIX = "# AI_TEAM_MANAGED_SHA256: "
GATE_B_EXAMPLE_PATH = Path("org_skills") / "03-submission-status-governance" / "references" / "gate-b.example.json"
PROJECT_LEVEL_GATE_B_INPUT = Path("00-项目包") / "04-过程文件" / "04-全量提交-gate-b.input.json"
MODULES_ROOT = Path("01-模块执行包")
MODULE_TEMPLATE_DIR_NAME = "模块模板"
MODULE_LEVEL_GATE_B_INPUT = Path("04-过程文件") / "gate-b.input.json"
PROJECT_LEVEL_ENGINEERING_HANDOFF_README = Path("00-项目包") / "02-工程交接" / "README.md"
GOVERNANCE_SKILL_ROOT = Path("org_skills") / "03-submission-status-governance"
PROJECT_TEMPLATE_ROOT = Path("assets") / "project_skeleton" / "00-项目包模板"
FORMAL_PROJECT_ENTRY_PATHS = (
    Path("00-项目包") / "00-项目包索引.md",
    PROJECT_LEVEL_ENGINEERING_HANDOFF_README,
    MODULES_ROOT / "00-模块索引.md",
    Path("80-完整提交包") / "00-提交说明.md",
    Path("80-完整提交包") / "01-合并PRD" / "00-PRD索引.md",
    Path("80-完整提交包") / "01-合并PRD" / "01-合并PRD阅读层.md",
    Path("80-完整提交包") / "02-原型索引" / "00-原型入口.md",
    Path("80-完整提交包") / "03-合并评审记录" / "00-评审索引.md",
)
FORMAL_ENTRY_UPGRADE_SIGNALS = {
    MODULES_ROOT / "00-模块索引.md": (
        "模块工程交接入口",
        "`80-完整提交包/` 不是事实源",
    ),
    Path("00-说明.md"): (
        "模块工程交接入口",
        "阅读层不是事实源",
    ),
    Path("01-PRD") / "01-模块PRD.md": (
        "canonical backlink",
        "linked_prd_source",
        "retired-truth marker",
    ),
    Path("80-完整提交包") / "00-提交说明.md": (
        "01-合并PRD/01-合并PRD阅读层.md",
        "工程交接入口是一等对外入口",
    ),
    Path("80-完整提交包") / "01-合并PRD" / "00-PRD索引.md": (
        "PRD阅读层总入口",
        "图给人看，结构化文字给 AI 和执行链看。",
    ),
    Path("80-完整提交包") / "02-原型索引" / "00-原型入口.md": (
        "原型索引展示层",
        "页面状态由 `80-完整提交包/00-提交状态.json` 派生",
    ),
    Path("80-完整提交包") / "03-合并评审记录" / "00-评审索引.md": (
        "评审视图",
        "校验未通过前，不得宣称“可进入人工评审”或“可最终提交”。",
    ),
}
FORMAL_MODULE_ENTRY_PATHS = (
    Path("00-说明.md"),
    Path("01-PRD") / "01-模块PRD.md",
)
MODULE_TEMPLATE_ROOT = MODULES_ROOT / MODULE_TEMPLATE_DIR_NAME
MISLEADING_HANDOFF_PHRASES = (
    "不代表已完成工程交接",
    "仅提供目录入口",
    "占位",
)
REQUIRED_RELEASE_METADATA_FIELDS = (
    "schema_version",
    "channel",
    "bundle_version",
    "bundle_source",
    "tag",
    "tarball_url",
    "manifest_url",
    "installer_archive_url",
    "installer_archive_sha256",
    "bundle_sha256",
)
RUNTIME_PROMPT_MATERIALIZATION_MODULE = (
    DEFAULT_BUNDLE_ROOT
    / "org_skills"
    / "00-dispatch-orchestration"
    / "scripts"
    / "runtime_prompt_materialization.py"
)


class InstallBlockedError(Exception):
    def __init__(self, payload: dict[str, Any]) -> None:
        super().__init__(payload.get("summary", "install blocked"))
        self.payload = payload


class ReleaseMetadataLoadError(Exception):
    def __init__(self, *, metadata_path: Path, message: str, reason_code: str) -> None:
        super().__init__(message)
        self.metadata_path = metadata_path
        self.message = message
        self.reason_code = reason_code


class GovernanceScriptRepairBlockedError(Exception):
    def __init__(
        self,
        *,
        conflicting_files: list[str],
        suggested_action: str,
    ) -> None:
        summary = (
            "Project-root governance scripts diverged from the shipped managed copy: "
            + ", ".join(conflicting_files)
        )
        super().__init__(summary)
        self.reason_code = "governance_script_diverged"
        self.summary = summary
        self.conflicting_files = conflicting_files
        self.suggested_action = suggested_action
        self.governance_event_written = False

    def mark_governance_event_written(self) -> None:
        self.governance_event_written = True

    def to_payload(self) -> dict[str, Any]:
        return {
            "result": "blocked",
            "reason_code": self.reason_code,
            "summary": self.summary,
            "conflicting_files": self.conflicting_files,
            "suggested_action": self.suggested_action,
            "governance_event_written": self.governance_event_written,
        }


def install_project(
    project_root: Path,
    *,
    allow_downgrade: bool = False,
    repair_governance_scripts: bool = False,
) -> dict[str, Any]:
    _guard_against_installing_into_methodology_repo_root(project_root)
    now = _utc_now()
    ai_team_root = project_root / ".ai-team"
    runtime_root = ai_team_root / "runtime" / "default_bundle"
    state_root = ai_team_root / "state"
    install_mode = "repair" if ai_team_root.exists() else "fresh"
    ignore_target = ensure_hidden_workspace_ignored(project_root)
    source_manifest = _load_bundle_manifest(DEFAULT_BUNDLE_ROOT / "manifest.json")
    try:
        release_metadata = _load_release_metadata()
    except ReleaseMetadataLoadError as exc:
        raise InstallBlockedError(
            {
                "result": "blocked",
                "reason_code": exc.reason_code,
                "summary": exc.message,
                "metadata_path": str(exc.metadata_path),
            }
        ) from None
    _guard_against_downgrade(
        project_root,
        source_manifest=source_manifest,
        release_metadata=release_metadata,
        allow_downgrade=allow_downgrade,
    )
    try:
        _materialize_runtime_bundle(DEFAULT_BUNDLE_ROOT, runtime_root, source_manifest)
    except FileNotFoundError as exc:
        raise InstallBlockedError(
            {
                "result": "blocked",
                "reason_code": "runtime_bundle_source_missing",
                "summary": str(exc),
            }
        ) from None
    runtime_manifest = _load_bundle_manifest(runtime_root / "manifest.json")
    lock_channel = _resolve_lock_channel(runtime_manifest, release_metadata)
    effective_bundle_version = _resolve_effective_bundle_version(runtime_manifest, release_metadata)
    effective_bundle_source = _resolve_effective_bundle_source(runtime_manifest, release_metadata)
    release_tag = _resolve_optional_release_str("tag", release_metadata)
    manifest_url = _resolve_release_value("manifest_url", runtime_manifest, release_metadata)
    bundle_sha256 = _resolve_release_value("bundle_sha256", runtime_manifest, release_metadata)
    prompt_path = runtime_root / str(runtime_manifest["startup_prompt"])

    try:
        governance_script_repair = _repair_project_root_governance_scripts(
            project_root=project_root,
            runtime_root=runtime_root,
            manifest=runtime_manifest,
            repair_governance_scripts=repair_governance_scripts,
        )
    except GovernanceScriptRepairBlockedError as exc:
        append_governance_event(
            project_root,
            event_type="repair",
            event_scope="canonical",
            latest_eligible=False,
            bundle_version=effective_bundle_version,
            release_tag=release_tag,
            input_refs=[str(DEFAULT_BUNDLE_ROOT / "manifest.json"), *exc.conflicting_files],
            output_refs=[],
            result="blocked",
            warnings=[],
            blockers=[exc.summary],
            written_targets=[],
            snapshot_targets=exc.conflicting_files,
            reason_code=exc.reason_code,
            conflicting_files=exc.conflicting_files,
            suggested_action=exc.suggested_action,
        )
        exc.mark_governance_event_written()
        raise InstallBlockedError(exc.to_payload()) from None

    submission_status_migration = _migrate_submission_status_shape(
        project_root=project_root,
        runtime_root=runtime_root,
        manifest=runtime_manifest,
    )
    formal_entry_repair = _ensure_formal_human_entry_files(
        project_root=project_root,
        runtime_root=runtime_root,
    )
    gate_b_evidence_pack_repair = _ensure_gate_b_evidence_packs(
        project_root=project_root,
        runtime_root=runtime_root,
    )
    engineering_handoff_starters = _ensure_engineering_handoff_starters(
        project_root=project_root,
        runtime_root=runtime_root,
    )
    try:
        total_control_repair = repair_total_control_authority(
            project_root,
            install_mode=install_mode,
        )
    except TotalControlRepairBlockedError as exc:
        append_governance_event(
            project_root,
            event_type="repair",
            event_scope="canonical",
            latest_eligible=False,
            bundle_version=effective_bundle_version,
            release_tag=release_tag,
            input_refs=[str(DEFAULT_BUNDLE_ROOT / "manifest.json")],
            output_refs=[],
            result="blocked",
            warnings=[],
            blockers=[exc.summary],
            written_targets=[],
            snapshot_targets=[exc.host_path.as_posix()] if exc.host_path is not None else [],
            reason_code=exc.reason_code,
        )
        raise InstallBlockedError(exc.to_payload()) from None
    release_metadata_path = _current_release_metadata_path()
    bundle_catalog = _build_bundle_catalog(runtime_manifest, runtime_root)
    inspection_entry, install_warnings = _cleanup_legacy_runtime_inspection_entry(project_root)

    lock_file = project_root / LOCK_FILE_NAME
    write_json(
        lock_file,
        {
            "schema_version": 1,
            "channel": lock_channel,
            "bundle_version": effective_bundle_version,
            "bundle_source": effective_bundle_source,
            "manifest_url": manifest_url,
            "bundle_sha256": bundle_sha256,
            "auto_understand_on_install": False,
        },
    )

    startup_prompt = render_startup_prompt(
        prompt_path,
        project_root,
        runtime_total_control_prompt_source(project_root, runtime_root),
    )

    write_json(
        ai_team_root / "install.json",
        {
            "schema_version": 1,
            "installed_at": now,
            "platform": platform.system().lower(),
            "project_root": str(project_root),
            "install_mode": install_mode,
            "result": "ok",
            "ignore_target": ignore_target,
            "release_metadata_path": str(release_metadata_path) if release_metadata_path is not None else None,
            "release_tag": release_tag,
        },
    )
    write_json(
        ai_team_root / "runtime.json",
        {
            "schema_version": 1,
            "project_root": str(project_root),
            "bundle_version": effective_bundle_version,
            "bundle_source": effective_bundle_source,
            "bundle_root": str(runtime_root),
            "runtime_state": "active",
            "managed": True,
            "manifest_url": manifest_url,
            "bundle_sha256": bundle_sha256,
            "release_tag": release_tag,
            "updated_at": now,
        },
    )
    write_json(
        state_root / "install-summary.json",
        {
            "schema_version": 1,
            "installed_at": now,
            "project_root": str(project_root),
            "install_mode": install_mode,
            "result": "ok",
            "ignore_target": ignore_target,
            "core_files_written": [
                LOCK_FILE_NAME,
                ".ai-team/install.json",
                ".ai-team/runtime.json",
                ".ai-team/state/install-summary.json",
                ".ai-team/state/structure-probe.json",
                ".ai-team/state/startup-prompt.txt",
                ".ai-team/state/bundle-catalog.json",
            ],
            "bundle_asset_counts": {
                section: len(entries) for section, entries in bundle_catalog["assets"].items()
            },
            "inspection_entry": inspection_entry,
            "governance_script_repair": governance_script_repair,
            "submission_status_migration": submission_status_migration,
            "formal_entry_repair": formal_entry_repair,
            "gate_b_evidence_pack_repair": gate_b_evidence_pack_repair,
            "engineering_handoff_starters": engineering_handoff_starters,
            "total_control_repair": total_control_repair,
            "warnings": install_warnings,
        },
    )
    write_json(state_root / "structure-probe.json", probe_structure(project_root))
    write_json(state_root / "bundle-catalog.json", bundle_catalog)
    (state_root / "startup-prompt.txt").write_text(startup_prompt + "\n", encoding="utf-8")

    install_written_targets = [
        LOCK_FILE_NAME,
        ".ai-team/install.json",
        ".ai-team/runtime.json",
        ".ai-team/state/install-summary.json",
        ".ai-team/state/structure-probe.json",
        ".ai-team/state/startup-prompt.txt",
        ".ai-team/state/bundle-catalog.json",
        *governance_script_repair["created"],
        *governance_script_repair["upgraded"],
        *governance_script_repair["adopted"],
        *governance_script_repair["backed_up"],
        *formal_entry_repair["created"],
        *formal_entry_repair["upgraded"],
        *gate_b_evidence_pack_repair["created"],
        *gate_b_evidence_pack_repair["migrated"],
        *engineering_handoff_starters["created"],
        *engineering_handoff_starters["upgraded"],
        *(
            [total_control_repair["host_path"]]
            if total_control_repair["status"] == "backfilled"
            else []
        ),
    ]
    install_snapshot_targets = [
        *install_written_targets,
        *governance_script_repair["unchanged"],
        *formal_entry_repair["unchanged"],
        *gate_b_evidence_pack_repair["unchanged"],
        *engineering_handoff_starters["unchanged"],
        *(
            [total_control_repair["host_path"]]
            if total_control_repair["status"] in {"unchanged", "backfilled"}
            else []
        ),
    ]
    if submission_status_migration["status"] == "migrated":
        install_snapshot_targets.append(submission_status_migration["path"])
    append_governance_event(
        project_root,
        event_type="install" if install_mode == "fresh" else "repair",
        bundle_version=effective_bundle_version,
        release_tag=release_tag,
        input_refs=[str(DEFAULT_BUNDLE_ROOT / "manifest.json")],
        output_refs=install_written_targets,
        result="ok",
        warnings=install_warnings,
        written_targets=install_written_targets,
        snapshot_targets=install_snapshot_targets,
    )
    if submission_status_migration["status"] == "migrated":
        append_governance_event(
            project_root,
            event_type="migration",
            latest_eligible=False,
            bundle_version=effective_bundle_version,
            release_tag=release_tag,
            input_refs=[submission_status_migration["path"]],
            output_refs=[submission_status_migration["path"]],
            result="ok",
            warnings=[],
            written_targets=[submission_status_migration["path"]],
        )

    return {
        "startup_prompt": startup_prompt,
        "human_entry_command": extract_human_entry_command(startup_prompt),
        "bundle_version": effective_bundle_version,
        "release_tag": release_tag,
        "project_runtime_state": "ready",
        "install_summary_path": str(state_root / "install-summary.json"),
        "warnings": install_warnings,
    }


def _guard_against_installing_into_methodology_repo_root(project_root: Path) -> None:
    if project_root != REPO_ROOT:
        return
    raise InstallBlockedError(
        {
            "result": "blocked",
            "reason_code": "methodology_source_repo_root_forbidden",
            "summary": "The methodology source repository root cannot be used as an ai-team install target.",
            "project_root": str(project_root),
            "suggested_action": "Run ai-team install inside a separate project root or a temporary sample project instead.",
        }
    )


def _load_release_metadata() -> dict[str, Any] | None:
    metadata_path = _current_release_metadata_path()
    if metadata_path is None:
        return None
    if not metadata_path.exists():
        raise ReleaseMetadataLoadError(
            metadata_path=metadata_path,
            message=f"Release metadata file does not exist: {metadata_path}",
            reason_code="release_metadata_missing",
        )
    try:
        payload = read_json(metadata_path)
    except OSError as exc:
        raise ReleaseMetadataLoadError(
            metadata_path=metadata_path,
            message=f"Release metadata file is unreadable: {metadata_path} ({exc})",
            reason_code="release_metadata_unreadable",
        ) from None
    except ValueError as exc:
        raise ReleaseMetadataLoadError(
            metadata_path=metadata_path,
            message=f"Release metadata file is invalid JSON: {metadata_path} ({exc})",
            reason_code="release_metadata_invalid",
        ) from None
    _validate_release_metadata(payload, metadata_path)
    _validate_release_metadata_trust(payload, metadata_path)
    return payload


def _guard_against_downgrade(
    project_root: Path,
    *,
    source_manifest: dict[str, Any],
    release_metadata: dict[str, Any] | None,
    allow_downgrade: bool,
) -> None:
    if allow_downgrade:
        return

    existing_runtime_payload = safe_read_json(project_root / ".ai-team" / "runtime.json")
    existing_bundle_version = _payload_str(existing_runtime_payload, "bundle_version")
    if existing_bundle_version is None:
        return

    incoming_bundle_version = _resolve_effective_bundle_version(source_manifest, release_metadata)
    version_comparison = compare_bundle_versions(incoming_bundle_version, existing_bundle_version)
    if version_comparison is None:
        if incoming_bundle_version == existing_bundle_version:
            return
        raise ValueError(
            "Refusing to replace project runtime "
            f"from {existing_bundle_version} to non-comparable bundle version {incoming_bundle_version}. "
            "Provide a valid release metadata contract or rerun with --allow-downgrade."
        )
    if version_comparison >= 0:
        return

    raise ValueError(
        "Refusing to downgrade project runtime "
        f"from {existing_bundle_version} to {incoming_bundle_version}. "
        "Upgrade the machine launcher or rerun with --allow-downgrade."
    )


def _current_release_metadata_path() -> Path | None:
    metadata_path_raw = os.environ.get("AI_TEAM_RELEASE_METADATA_PATH")
    if not metadata_path_raw:
        return None
    return Path(metadata_path_raw)


def _validate_release_metadata(payload: dict[str, Any], metadata_path: Path) -> None:
    for key in REQUIRED_RELEASE_METADATA_FIELDS:
        value = payload.get(key)
        if isinstance(value, str):
            if value.strip():
                continue
        elif key == "schema_version" and isinstance(value, int):
            continue
        raise ReleaseMetadataLoadError(
            metadata_path=metadata_path,
            message=f"Release metadata missing required field: {key}",
            reason_code="release_metadata_invalid",
        )


def _validate_release_metadata_trust(payload: dict[str, Any], metadata_path: Path) -> None:
    machine_state = read_machine_install_state()
    if machine_state is None:
        raise ReleaseMetadataLoadError(
            metadata_path=metadata_path,
            message=(
                "Release metadata cannot be trusted without machine install state. "
                "Run the launcher bootstrap first, then install the project."
            ),
            reason_code="release_metadata_untrusted",
        )

    expected_pairs = (
        ("bundle_version", "bundle_version"),
        ("tag", "release_tag"),
        ("installer_archive_sha256", "installer_archive_sha256"),
    )
    for metadata_key, state_key in expected_pairs:
        metadata_value = payload.get(metadata_key)
        state_value = machine_state.get(state_key)
        if isinstance(metadata_value, str) and isinstance(state_value, str) and metadata_value == state_value:
            continue
        raise ReleaseMetadataLoadError(
            metadata_path=metadata_path,
            message=(
                "Release metadata does not match the machine launcher install state: "
                f"{metadata_key} != {state_key}"
            ),
            reason_code="release_metadata_untrusted",
        )


def _resolve_lock_channel(runtime_manifest: dict[str, Any], release_metadata: dict[str, Any] | None) -> str:
    if release_metadata is not None:
        value = release_metadata.get("channel")
        if isinstance(value, str) and value:
            return value
    value = runtime_manifest.get("channel", "stable")
    if isinstance(value, str) and value:
        return value
    return "stable"


def _resolve_effective_bundle_version(
    runtime_manifest: dict[str, Any],
    release_metadata: dict[str, Any] | None,
) -> str:
    if release_metadata is not None:
        value = release_metadata.get("bundle_version")
        if isinstance(value, str) and value:
            return value
    value = runtime_manifest.get("bundle_version")
    if isinstance(value, str) and value:
        return value
    raise ValueError("Bundle version must be a non-empty string.")


def _resolve_effective_bundle_source(
    runtime_manifest: dict[str, Any],
    release_metadata: dict[str, Any] | None,
) -> str:
    if release_metadata is not None:
        value = release_metadata.get("bundle_source")
        if isinstance(value, str) and value:
            return value
    value = runtime_manifest.get("bundle_source")
    if isinstance(value, str) and value:
        return value
    raise ValueError("Bundle source must be a non-empty string.")


def _resolve_release_value(
    key: str,
    runtime_manifest: dict[str, Any],
    release_metadata: dict[str, Any] | None,
) -> str | None:
    if release_metadata is not None:
        value = release_metadata.get(key)
        if isinstance(value, str) and value:
            return value
    value = runtime_manifest.get(key)
    if isinstance(value, str) and value:
        return value
    return None


def _resolve_optional_release_str(key: str, release_metadata: dict[str, Any] | None) -> str | None:
    if release_metadata is None:
        return None
    value = release_metadata.get(key)
    if isinstance(value, str) and value:
        return value
    return None


def _payload_str(payload: dict[str, Any] | None, key: str) -> str | None:
    if payload is None:
        return None
    value = payload.get(key)
    if isinstance(value, str) and value:
        return value
    return None


def _cleanup_legacy_runtime_inspection_entry(project_root: Path) -> tuple[dict[str, str], list[str]]:
    inspect_path = project_root / INSPECTION_LINK_NAME
    target = INSPECTION_LINK_TARGET.as_posix()
    entry = {
        "path": INSPECTION_LINK_NAME,
        "target": target,
        "status": "not_present",
    }
    warnings: list[str] = []

    try:
        if inspect_path.is_symlink():
            if os.readlink(inspect_path) == target:
                inspect_path.unlink()
                entry["status"] = "removed"
                return entry, warnings
            entry["status"] = "blocked"
            warnings.append(f"{INSPECTION_LINK_NAME} is occupied by a non-standard symlink and was left unchanged")
            return entry, warnings

        if inspect_path.exists():
            entry["status"] = "blocked"
            warnings.append(f"{INSPECTION_LINK_NAME} is occupied and was left unchanged")
            return entry, warnings
    except OSError as exc:
        entry["status"] = "failed"
        entry["error"] = str(exc)
        warnings.append(f"unable to clean up {INSPECTION_LINK_NAME}: {exc}")
        return entry, warnings

    return entry, warnings


def _repair_project_root_governance_scripts(
    *,
    project_root: Path,
    runtime_root: Path,
    manifest: dict[str, Any],
    repair_governance_scripts: bool,
) -> dict[str, list[str]]:
    project_template_root = runtime_root / _asset_base_relative(manifest)["project_template_scripts"]
    entries = manifest.get("project_template_scripts", [])
    if not isinstance(entries, list):
        raise ValueError("Manifest section project_template_scripts must be a list.")

    created: list[str] = []
    upgraded: list[str] = []
    adopted: list[str] = []
    backed_up: list[str] = []
    unchanged: list[str] = []
    blocked: list[str] = []
    planned_repairs: list[dict[str, Any]] = []
    backup_root = (
        project_root
        / ".ai-team"
        / "state"
        / "governance-script-backups"
        / _utc_timestamp_slug()
    )

    for rel in entries:
        if not isinstance(rel, str) or not rel:
            raise ValueError(f"Manifest section project_template_scripts contains an invalid entry: {rel!r}")
        relative_path = Path(rel)
        target_path = project_root / relative_path
        _, source_text = _managed_project_template_script_source(
            runtime_root=runtime_root,
            project_template_root=project_template_root,
            relative_path=relative_path,
        )
        outcome = _classify_project_root_governance_script(
            relative_path=relative_path,
            source_text=source_text,
            target_path=target_path,
            repair_governance_scripts=repair_governance_scripts,
        )
        planned_repairs.append(outcome)
        state = outcome["state"]
        if state == "missing":
            created.append(rel)
        elif state == "managed_old":
            upgraded.append(rel)
        elif state == "unmanaged_equal":
            adopted.append(rel)
        elif state == "current":
            unchanged.append(rel)
        elif state == "unmanaged_diverged":
            if outcome["repaired"]:
                upgraded.append(rel)
            else:
                blocked.append(rel)
        else:
            blocked.append(rel)

    if blocked:
        raise GovernanceScriptRepairBlockedError(
            conflicting_files=blocked,
            suggested_action=(
                f"Rerun with: ai-team install --project-root {project_root} --repair-governance-scripts"
            ),
        )

    for outcome in planned_repairs:
        _apply_project_root_governance_script_repair(
            project_root=project_root,
            outcome=outcome,
            backup_root=backup_root,
        )
        backup_path = outcome.get("backup_path")
        if isinstance(backup_path, str) and backup_path:
            backed_up.append(backup_path)

    return {
        "created": created,
        "upgraded": upgraded,
        "adopted": adopted,
        "backed_up": backed_up,
        "unchanged": unchanged,
        "blocked": blocked,
    }


def _classify_project_root_governance_script(
    *,
    relative_path: Path,
    source_text: str,
    target_path: Path,
    repair_governance_scripts: bool,
) -> dict[str, Any]:
    if not target_path.exists():
        return {
            "state": "missing",
            "repaired": True,
            "relative_path": relative_path,
            "target_path": target_path,
            "source_text": source_text,
        }

    target_text = target_path.read_text(encoding="utf-8")
    if target_text == source_text:
        return {
            "state": "current",
            "repaired": False,
            "relative_path": relative_path,
            "target_path": target_path,
            "source_text": source_text,
            "current_text": target_text,
        }

    if _is_valid_managed_script_copy(target_text, expected_source=relative_path.as_posix()):
        return {
            "state": "managed_old",
            "repaired": True,
            "relative_path": relative_path,
            "target_path": target_path,
            "source_text": source_text,
            "current_text": target_text,
        }

    if target_text == _extract_managed_script_metadata(source_text)[2]:
        return {
            "state": "unmanaged_equal",
            "repaired": True,
            "relative_path": relative_path,
            "target_path": target_path,
            "source_text": source_text,
            "current_text": target_text,
        }

    if not repair_governance_scripts:
        return {
            "state": "unmanaged_diverged",
            "repaired": False,
            "relative_path": relative_path,
            "target_path": target_path,
            "source_text": source_text,
            "current_text": target_text,
        }

    return {
        "state": "unmanaged_diverged",
        "repaired": True,
        "relative_path": relative_path,
        "target_path": target_path,
        "source_text": source_text,
        "current_text": target_text,
    }


def _apply_project_root_governance_script_repair(
    *,
    project_root: Path,
    outcome: dict[str, Any],
    backup_root: Path,
) -> None:
    state = outcome["state"]
    target_path = outcome["target_path"]
    source_text = outcome["source_text"]

    if state == "current":
        return

    if state == "unmanaged_diverged":
        backup_path = backup_root / outcome["relative_path"]
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        backup_path.write_text(outcome["current_text"], encoding="utf-8")
        outcome["backup_path"] = backup_path.relative_to(project_root).as_posix()

    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text(source_text, encoding="utf-8")


def _managed_project_template_script_source(
    *,
    runtime_root: Path,
    project_template_root: Path,
    relative_path: Path,
) -> tuple[str, str]:
    managed_relative = relative_path.as_posix()
    governance_source_path = runtime_root / GOVERNANCE_SKILL_ROOT / relative_path
    if not governance_source_path.exists():
        template_source_path = project_template_root / relative_path
        raise FileNotFoundError(
            "Managed governance script source does not exist in runtime org_skills: "
            f"{governance_source_path} (template mirror also present at {template_source_path})"
        )
    return str(governance_source_path), _stamp_managed_script_copy(
        managed_relative,
        governance_source_path.read_text(encoding="utf-8"),
    )


def _stamp_managed_script_copy(relative_source: str, text: str) -> str:
    shebang, body = _split_shebang_and_body(text)
    payload = f"{shebang}{body}"
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    header = (
        f"{MANAGED_SOURCE_PREFIX}{relative_source}\n"
        f"{MANAGED_SHA256_PREFIX}{digest}\n"
    )
    return f"{shebang}{header}{body}"


def _migrate_submission_status_shape(
    *,
    project_root: Path,
    runtime_root: Path,
    manifest: dict[str, Any],
) -> dict[str, Any]:
    relative_path = Path("80-完整提交包/00-提交状态.json")
    project_status_path = project_root / relative_path
    if not project_status_path.exists():
        return {"status": "not_present", "path": str(relative_path)}

    template_status_path = (
        runtime_root
        / _asset_base_relative(manifest)["project_skeleton_files"]
        / relative_path
    )
    template_payload = read_json(template_status_path)
    current_payload = read_json(project_status_path)
    migrated_payload, changed = _merge_status_shape(
        current=current_payload,
        template=template_payload,
        path=relative_path.as_posix(),
    )
    if changed:
        write_json(project_status_path, migrated_payload)
    return {
        "status": "migrated" if changed else "unchanged",
        "path": str(relative_path),
    }


def _ensure_gate_b_evidence_packs(
    *,
    project_root: Path,
    runtime_root: Path,
) -> dict[str, list[str]]:
    created: list[str] = []
    migrated: list[str] = []
    unchanged: list[str] = []
    template_path = runtime_root / GATE_B_EXAMPLE_PATH
    if not template_path.exists():
        return {
            "created": created,
            "migrated": migrated,
            "unchanged": unchanged,
        }
    template_payload = read_json(template_path)

    if (project_root / "00-项目包").exists():
        project_level_path = project_root / PROJECT_LEVEL_GATE_B_INPUT
        if project_level_path.exists():
            migrated_payload, changed = _migrate_gate_b_evidence_pack(
                current=read_json(project_level_path),
                template=template_payload,
                module_id=project_root.name,
                starter_kind="project",
                path=PROJECT_LEVEL_GATE_B_INPUT.as_posix(),
            )
            if changed:
                write_json(project_level_path, migrated_payload)
                migrated.append(PROJECT_LEVEL_GATE_B_INPUT.as_posix())
            else:
                unchanged.append(PROJECT_LEVEL_GATE_B_INPUT.as_posix())
        else:
            write_json(
                project_level_path,
                _starter_gate_b_payload(
                    template_payload,
                    module_id=project_root.name,
                    starter_kind="project",
                ),
            )
            created.append(PROJECT_LEVEL_GATE_B_INPUT.as_posix())

    modules_root = project_root / MODULES_ROOT
    if modules_root.exists():
        for module_dir in _iter_real_module_dirs(modules_root):
            target_path = module_dir / MODULE_LEVEL_GATE_B_INPUT
            rel_path = target_path.relative_to(project_root).as_posix()
            if target_path.exists():
                migrated_payload, changed = _migrate_gate_b_evidence_pack(
                    current=read_json(target_path),
                    template=template_payload,
                    module_id=module_dir.name,
                    starter_kind="module",
                    path=rel_path,
                )
                if changed:
                    write_json(target_path, migrated_payload)
                    migrated.append(rel_path)
                else:
                    unchanged.append(rel_path)
                continue
            write_json(
                target_path,
                _starter_gate_b_payload(
                    template_payload,
                    module_id=module_dir.name,
                    starter_kind="module",
                ),
            )
            created.append(rel_path)

    return {
        "created": created,
        "migrated": migrated,
        "unchanged": unchanged,
    }


def _ensure_engineering_handoff_starters(
    *,
    project_root: Path,
    runtime_root: Path,
) -> dict[str, list[str]]:
    created: list[str] = []
    upgraded: list[str] = []
    unchanged: list[str] = []
    template_root = runtime_root / PROJECT_TEMPLATE_ROOT
    template_readme_path = template_root / PROJECT_LEVEL_ENGINEERING_HANDOFF_README
    template_readme_text = template_readme_path.read_text(encoding="utf-8") if template_readme_path.exists() else "# 工程交接资料目录\n"
    module_template_readme_path = template_root / MODULE_TEMPLATE_ROOT / "02-工程交接" / "README.md"
    module_template_readme_text = (
        module_template_readme_path.read_text(encoding="utf-8")
        if module_template_readme_path.exists()
        else template_readme_text
    )

    project_readme_path = project_root / PROJECT_LEVEL_ENGINEERING_HANDOFF_README
    if (project_root / "00-项目包").exists():
        project_readme_state = _ensure_formal_handoff_readme(
            target_path=project_readme_path,
            template_text=template_readme_text,
        )
        if project_readme_state == "created":
            created.append(project_readme_path.relative_to(project_root).as_posix())
        elif project_readme_state == "upgraded":
            upgraded.append(project_readme_path.relative_to(project_root).as_posix())
        else:
            unchanged.append(project_readme_path.relative_to(project_root).as_posix())

    modules_root = project_root / MODULES_ROOT
    if not modules_root.exists():
        return {"created": created, "upgraded": upgraded, "unchanged": unchanged}

    for module_dir in _iter_real_module_dirs(modules_root):
        module_name = module_dir.name
        readme_path = module_dir / "02-工程交接" / "README.md"
        checklist_path = module_dir / "04-过程文件" / f"{module_name}-工程交接门槛清单.md"
        ledger_path = module_dir / "04-过程文件" / f"{module_name}-跨角色预审讨论清单.md"

        readme_state = _ensure_formal_handoff_readme(
            target_path=readme_path,
            template_text=module_template_readme_text,
        )
        if readme_state == "created":
            created.append(readme_path.relative_to(project_root).as_posix())
        elif readme_state == "upgraded":
            upgraded.append(readme_path.relative_to(project_root).as_posix())
        else:
            unchanged.append(readme_path.relative_to(project_root).as_posix())

        if checklist_path.exists():
            unchanged.append(checklist_path.relative_to(project_root).as_posix())
        else:
            _write_text_file(
                checklist_path,
                _starter_checklist_text(module_name),
            )
            created.append(checklist_path.relative_to(project_root).as_posix())

        if ledger_path.exists():
            unchanged.append(ledger_path.relative_to(project_root).as_posix())
        else:
            _write_text_file(
                ledger_path,
                _starter_precheck_ledger_text(module_name),
            )
            created.append(ledger_path.relative_to(project_root).as_posix())

    return {"created": created, "upgraded": upgraded, "unchanged": unchanged}


def _ensure_formal_human_entry_files(
    *,
    project_root: Path,
    runtime_root: Path,
) -> dict[str, list[str]]:
    created: list[str] = []
    upgraded: list[str] = []
    unchanged: list[str] = []
    template_root = runtime_root / PROJECT_TEMPLATE_ROOT
    missing_sources: list[str] = []

    for relative_path in FORMAL_PROJECT_ENTRY_PATHS:
        source_path = template_root / relative_path
        if not source_path.exists():
            missing_sources.append(source_path.relative_to(runtime_root).as_posix())

    template_module_root = template_root / MODULE_TEMPLATE_ROOT
    for relative_path in FORMAL_MODULE_ENTRY_PATHS:
        source_path = template_module_root / relative_path
        if not source_path.exists():
            missing_sources.append(source_path.relative_to(runtime_root).as_posix())

    if missing_sources:
        raise InstallBlockedError(
            {
                "result": "blocked",
                "reason_code": "formal_entry_template_missing",
                "summary": "Runtime bundle is missing required formal human entry templates.",
                "missing_sources": sorted(missing_sources),
            }
        )

    for relative_path in FORMAL_PROJECT_ENTRY_PATHS:
        target_path = project_root / relative_path
        source_path = template_root / relative_path
        action = _ensure_formal_entry_file(
            target_path=target_path,
            template_text=source_path.read_text(encoding="utf-8"),
            relative_path=relative_path,
        )
        if action == "created":
            created.append(relative_path.as_posix())
        elif action == "upgraded":
            upgraded.append(relative_path.as_posix())
        else:
            unchanged.append(relative_path.as_posix())

    modules_root = project_root / MODULES_ROOT
    if modules_root.exists():
        for module_dir in _iter_real_module_dirs(modules_root):
            for relative_path in FORMAL_MODULE_ENTRY_PATHS:
                target_path = module_dir / relative_path
                source_path = template_module_root / relative_path
                rel_path = target_path.relative_to(project_root).as_posix()
                action = _ensure_formal_entry_file(
                    target_path=target_path,
                    template_text=source_path.read_text(encoding="utf-8"),
                    relative_path=relative_path,
                )
                if action == "created":
                    created.append(rel_path)
                elif action == "upgraded":
                    upgraded.append(rel_path)
                else:
                    unchanged.append(rel_path)

    return {"created": created, "upgraded": upgraded, "unchanged": unchanged}


def _ensure_formal_handoff_readme(*, target_path: Path, template_text: str) -> str:
    if target_path.exists():
        current_text = target_path.read_text(encoding="utf-8")
        if not _looks_like_legacy_handoff_starter(current_text):
            return "unchanged"
        _write_text_file(target_path, template_text)
        return "upgraded"

    _write_text_file(target_path, template_text)
    return "created"


def _ensure_formal_entry_file(*, target_path: Path, template_text: str, relative_path: Path) -> str:
    if target_path.exists():
        current_text = target_path.read_text(encoding="utf-8")
        if current_text == template_text:
            return "unchanged"
        if _looks_like_stale_formal_entry(relative_path, current_text):
            _write_text_file(target_path, template_text)
            return "upgraded"
        return "unchanged"

    _write_text_file(target_path, template_text)
    return "created"


def _looks_like_stale_formal_entry(relative_path: Path, text: str) -> bool:
    signals = FORMAL_ENTRY_UPGRADE_SIGNALS.get(relative_path)
    if not signals:
        return False
    return any(signal not in text for signal in signals)


def _looks_like_legacy_handoff_starter(text: str) -> bool:
    for line in text.splitlines():
        normalized = line.strip()
        if not normalized:
            continue
        if "不再使用" in normalized:
            continue
        lowered = normalized.lower()
        if "starter" in lowered:
            return True
        if any(phrase in normalized for phrase in MISLEADING_HANDOFF_PHRASES):
            return True
    return False


def _iter_real_module_dirs(modules_root: Path) -> list[Path]:
    return sorted(
        (
            entry
            for entry in modules_root.iterdir()
            if entry.is_dir() and entry.name != MODULE_TEMPLATE_DIR_NAME
        ),
        key=lambda item: item.name,
    )


def _starter_gate_b_payload(template_payload: dict[str, Any], *, module_id: str, starter_kind: str) -> dict[str, Any]:
    payload = dict(template_payload)
    module_payload = {
        "module_id": module_id,
        "ready_for_human_review": False,
        "engineering_handoff_required": False,
        "engineering_handoff_triggers": [],
        "handoff_context": {"engineering_review_requested": False},
        "scope": {
            "has_ui": False,
            "requires_backend": False,
            "multi_role": False,
            "affects_persistence": False,
            "has_operational_risk": False,
        },
        "declared_triggers": [],
        "product_truth_signals": {},
        "artifact_owner_map": {},
        "required_supporting_docs": [],
        "unresolved_issue_ledger_ref": {"na": True, "rationale": "starter placeholder"},
        "fe_truth_source_ref_or_na": {"na": True, "rationale": "starter placeholder"},
        "be_truth_source_ref_or_na": {"na": True, "rationale": "starter placeholder"},
        "qa_truth_source_ref": {"path": ""},
        "dba_truth_source_ref_or_na": {"na": True, "rationale": "starter placeholder"},
        "ops_truth_source_ref_or_na": {"na": True, "rationale": "starter placeholder"},
        "legacy_migration_record": None,
        "artifact_refs": {},
        "starter_kind": starter_kind,
    }
    payload["module"] = module_payload
    payload["registry"] = template_payload["registry"]
    return payload


def _migrate_gate_b_evidence_pack(
    *,
    current: dict[str, Any],
    template: dict[str, Any],
    module_id: str,
    starter_kind: str,
    path: str,
) -> tuple[dict[str, Any], bool]:
    starter_payload = _starter_gate_b_payload(
        template,
        module_id=module_id,
        starter_kind=starter_kind,
    )
    normalized_current = _normalize_legacy_gate_b_payload(current)
    merged_payload, changed = _merge_status_shape(
        current=normalized_current,
        template=starter_payload,
        path=path,
    )

    normalized_payload = dict(merged_payload)
    for contract_key in ("schema", "schema_version", "registry_version", "linked_rule_version"):
        expected_value = starter_payload.get(contract_key)
        if normalized_payload.get(contract_key) != expected_value:
            normalized_payload[contract_key] = expected_value
            changed = True

    merged_registry = _merge_gate_b_registry(
        normalized_payload.get("registry"),
        starter_payload["registry"],
    )
    if normalized_payload.get("registry") != merged_registry:
        normalized_payload["registry"] = merged_registry
        changed = True

    return normalized_payload, changed


def _normalize_legacy_gate_b_payload(payload: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(payload)
    module_payload = normalized.get("module")
    if not isinstance(module_payload, dict):
        return normalized

    normalized_module = dict(module_payload)
    path_ref_fields = (
        "unresolved_issue_ledger_ref",
        "qa_truth_source_ref",
    )
    path_or_na_fields = (
        "fe_truth_source_ref_or_na",
        "be_truth_source_ref_or_na",
        "dba_truth_source_ref_or_na",
        "ops_truth_source_ref_or_na",
    )

    for field_name in (*path_ref_fields, *path_or_na_fields):
        value = normalized_module.get(field_name)
        if not isinstance(value, str):
            continue
        text = value.strip()
        if not text:
            continue
        if field_name in path_or_na_fields and text.upper() in {"N/A", "NA"}:
            normalized_module[field_name] = {
                "na": True,
                "rationale": "migrated from legacy string marker",
            }
        else:
            normalized_module[field_name] = {"path": text}

    normalized["module"] = normalized_module
    return normalized


def _merge_gate_b_registry(current: Any, authoritative: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(current, dict):
        return dict(authoritative)

    merged = dict(current)
    merged["approved_repository_scopes"] = authoritative["approved_repository_scopes"]
    merged["artifact_registry"] = authoritative["artifact_registry"]
    return merged


def _starter_checklist_text(module_name: str) -> str:
    return "\n".join(
        [
            "Owner: `总控`",
            "Status: `starter`",
            "Version: `v0`",
            f"Linked PRD: `01-模块执行包/{module_name}/01-PRD/`",
            "",
            f"# {module_name} 工程交接门槛清单（Starter）",
            "",
            "- 本文件仅在缺失时自动生成，不代表 Gate B 已通过。",
            "- 需要人工补齐 trigger、owner、required supporting docs 与最终结论。",
            "",
            f"module_id: {module_name}",
            "engineering_handoff_ready: false",
            "required_supporting_docs: pending_fill",
            "",
        ]
    )


def _starter_precheck_ledger_text(module_name: str) -> str:
    return "\n".join(
        [
            "Owner: `总控`",
            "Status: `starter`",
            "Version: `v0`",
            f"Linked PRD: `01-模块执行包/{module_name}/01-PRD/`",
            "",
            f"# {module_name} 跨角色预审讨论清单（Starter）",
            "",
            "- 本文件仅在缺失时自动生成，需人工补齐真实未决项和责任归属。",
            "",
            "blocker: pending_fill",
            "owner: 总控",
            "status: open",
            "",
        ]
    )


def _write_text_file(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _merge_status_shape(
    *,
    current: Any,
    template: Any,
    path: str,
) -> tuple[Any, bool]:
    if isinstance(template, dict):
        if not isinstance(current, dict):
            raise ValueError(f"semantic conflict in {path}: expected object")
        changed = False
        merged = dict(current)
        for key, template_value in template.items():
            child_path = f"{path}.{key}"
            if key not in current:
                merged[key] = template_value
                changed = True
                continue
            merged_value, child_changed = _merge_status_shape(
                current=current[key],
                template=template_value,
                path=child_path,
            )
            merged[key] = merged_value
            changed = changed or child_changed
        return merged, changed

    if isinstance(template, list):
        if not isinstance(current, list):
            raise ValueError(f"semantic conflict in {path}: expected list")
        return current, False

    if template is None:
        return current, False

    if isinstance(template, bool):
        if not isinstance(current, bool):
            raise ValueError(f"semantic conflict in {path}: expected boolean")
        return current, False

    if isinstance(template, str):
        if not isinstance(current, str):
            raise ValueError(f"semantic conflict in {path}: expected string")
        return current, False

    if isinstance(template, (int, float)):
        if not isinstance(current, (int, float)) or isinstance(current, bool):
            raise ValueError(f"semantic conflict in {path}: expected number")
        return current, False

    return current, False


def _is_valid_managed_script_copy(text: str, *, expected_source: str) -> bool:
    managed_source, managed_sha256, payload = _extract_managed_script_metadata(text)
    if managed_source != expected_source or managed_sha256 is None:
        return False
    actual_sha256 = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return actual_sha256 == managed_sha256


def _extract_managed_script_metadata(text: str) -> tuple[str | None, str | None, str]:
    shebang, body = _split_shebang_and_body(text)
    lines = body.splitlines(keepends=True)
    managed_source = None
    managed_sha256 = None
    payload_start = 0

    if len(lines) >= 2 and lines[0].startswith(MANAGED_SOURCE_PREFIX) and lines[1].startswith(MANAGED_SHA256_PREFIX):
        managed_source = lines[0][len(MANAGED_SOURCE_PREFIX) :].strip()
        managed_sha256 = lines[1][len(MANAGED_SHA256_PREFIX) :].strip()
        payload_start = 2

    payload = f"{shebang}{''.join(lines[payload_start:])}"
    return managed_source, managed_sha256, payload


def _split_shebang_and_body(text: str) -> tuple[str, str]:
    if text.startswith("#!"):
        first_line, remainder = text.split("\n", 1)
        return f"{first_line}\n", remainder
    return "", text


def _load_bundle_manifest(path: Path) -> dict[str, Any]:
    return read_json(path)


def _materialize_runtime_bundle(source_root: Path, runtime_root: Path, manifest: dict[str, Any]) -> None:
    required_rel_paths = {
        Path("manifest.json"),
        Path(str(manifest["startup_prompt"])),
        Path(_required_manifest_str(manifest, "org_skill_readme")),
    }

    for section, rel_base in _asset_base_relative(manifest).items():
        entries = manifest.get(section, [])
        if not isinstance(entries, list):
            raise ValueError(f"Manifest section {section} must be a list.")
        for rel in entries:
            if not isinstance(rel, str) or not rel:
                raise ValueError(f"Manifest section {section} contains an invalid entry: {rel!r}")
            required_rel_paths.add(rel_base / rel)

    for rel_path in sorted(required_rel_paths, key=lambda value: value.as_posix()):
        source_path = source_root / rel_path
        target_path = runtime_root / rel_path
        _copy_bundle_file(source_path, target_path)

    _materialize_runtime_prompt_surfaces(runtime_root, manifest)


def _load_runtime_prompt_materializer() -> Any:
    spec = spec_from_file_location(
        "ai_team_runtime_prompt_materialization",
        RUNTIME_PROMPT_MATERIALIZATION_MODULE,
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(
            "Could not load runtime prompt materialization helper: "
            f"{RUNTIME_PROMPT_MATERIALIZATION_MODULE}"
        )
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    materializer = getattr(module, "materialize_runtime_surface_text", None)
    if not callable(materializer):
        raise RuntimeError(
            "Runtime prompt materialization helper missing callable `materialize_runtime_surface_text`: "
            f"{RUNTIME_PROMPT_MATERIALIZATION_MODULE}"
        )
    return materializer


def _materialize_runtime_prompt_surfaces(runtime_root: Path, manifest: dict[str, Any]) -> None:
    materializer = _load_runtime_prompt_materializer()
    prompt_rel_paths: set[Path] = {Path(str(manifest["startup_prompt"]))}
    asset_bases = _asset_base_relative(manifest)

    for section in ("control_plane_agents", "execution_agents", "review_agents"):
        rel_base = asset_bases[section]
        entries = manifest.get(section, [])
        if not isinstance(entries, list):
            raise ValueError(f"Manifest section {section} must be a list.")
        for entry in entries:
            if not isinstance(entry, str) or not entry:
                raise ValueError(f"Manifest section {section} contains an invalid entry: {entry!r}")
            prompt_rel_paths.add(rel_base / entry)

    for rel_path in sorted(prompt_rel_paths, key=lambda value: value.as_posix()):
        target_path = runtime_root / rel_path
        text = target_path.read_text(encoding="utf-8")
        frontmatter = re.match(r"^---\n.*?\n---\n?", text, re.DOTALL)
        if frontmatter:
            materialized = text[: frontmatter.end()] + materializer(text[frontmatter.end() :])
        else:
            materialized = materializer(text)
        if materialized != text:
            target_path.write_text(materialized, encoding="utf-8")


def _copy_bundle_file(source_path: Path, target_path: Path) -> None:
    if source_path.is_dir():
        _copy_bundle_directory(source_path, target_path)
        return

    target_path.parent.mkdir(parents=True, exist_ok=True)
    if not source_path.exists():
        raise FileNotFoundError(f"Bundle source file does not exist: {source_path}")
    target_path.write_bytes(source_path.read_bytes())


def _copy_bundle_directory(source_dir: Path, target_dir: Path) -> None:
    if not source_dir.exists():
        raise FileNotFoundError(f"Bundle source directory does not exist: {source_dir}")

    for source_path in source_dir.rglob("*"):
        relative_path = source_path.relative_to(source_dir)
        if _should_skip_bundle_relative_path(relative_path):
            continue
        target_path = target_dir / relative_path
        if source_path.is_dir():
            target_path.mkdir(parents=True, exist_ok=True)
            continue
        _copy_bundle_file(source_path, target_path)


def _should_skip_bundle_relative_path(relative_path: Path) -> bool:
    return (
        "__pycache__" in relative_path.parts
        or relative_path.suffix in {".pyc", ".pyo"}
        or relative_path.name == ".DS_Store"
    )


def _build_bundle_catalog(manifest: dict[str, Any], bundle_root: Path) -> dict[str, Any]:
    assets: dict[str, list[str]] = {}
    resolved_assets: dict[str, list[str]] = {}
    asset_bases = _asset_base_relative(manifest)

    for section, rel_base in asset_bases.items():
        entries = manifest.get(section, [])
        if not isinstance(entries, list):
            raise ValueError(f"Manifest section {section} must be a list.")

        assets[section] = []
        resolved_assets[section] = []
        for rel in entries:
            if not isinstance(rel, str) or not rel:
                raise ValueError(f"Manifest section {section} contains an invalid entry: {rel!r}")
            target = bundle_root / rel_base / rel
            if not target.exists():
                raise FileNotFoundError(f"Bundle asset declared in {section} does not exist: {rel}")
            assets[section].append(rel)
            resolved_assets[section].append(str(target))

    return {
        "schema_version": manifest["schema_version"],
        "bundle_id": manifest.get("bundle_id", "default-methodology-bundle"),
        "bundle_version": manifest["bundle_version"],
        "bundle_source": manifest["bundle_source"],
        "bundle_root": str(bundle_root),
        "startup_prompt": manifest["startup_prompt"],
        "assets": assets,
        "resolved_assets": resolved_assets,
    }


def _asset_base_relative(manifest: dict[str, Any]) -> dict[str, Path]:
    agents_root = Path(_required_manifest_str(manifest, "agents_root"))
    assets_root = Path(_required_manifest_str(manifest, "assets_root"))
    org_skill_root = Path(_required_manifest_str(manifest, "org_skill_root"))
    project_template_root = assets_root / "project_skeleton" / "00-项目包模板"

    return {
        "project_skeleton_files": project_template_root,
        "project_template_scripts": project_template_root,
        "control_plane_agents": agents_root,
        "execution_agents": agents_root,
        "review_agents": agents_root,
        "rule_files": assets_root / "rules",
        "contract_files": assets_root / "contracts",
        "template_files": assets_root / "templates",
        "review_template_files": assets_root / "templates",
        "internal_org_skill_packages": org_skill_root,
        "skills": org_skill_root,
    }


def _required_manifest_str(manifest: dict[str, Any], key: str) -> str:
    value = manifest.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"Manifest field {key} must be a non-empty string.")
    return value


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _utc_timestamp_slug() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
