# PRD索引

<!-- SUBMISSION_STATUS:BEGIN -->
## 提交状态

- PRD状态：`draft`
- 原型状态：`draft`
- 评审状态：`draft`
- 当前阶段：`drafting`
- 可进入人工评审：`no`
- 最新评审批次：`pending`
- 状态真源：[00-提交状态.json](../00-提交状态.json)
<!-- SUBMISSION_STATUS:END -->

- 状态：`draft`
