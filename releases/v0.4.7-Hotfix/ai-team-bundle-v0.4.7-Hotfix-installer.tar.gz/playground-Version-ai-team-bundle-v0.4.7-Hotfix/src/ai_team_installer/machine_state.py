from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


SEMVER_PATTERN = re.compile(r"^v?(?P<core>\d+(?:\.\d+)*)(?:-(?P<prerelease>[0-9A-Za-z.-]+))?$")


def machine_install_root(home: Path | None = None) -> Path:
    return (home or Path.home()) / ".ai-team"


def machine_state_root(home: Path | None = None) -> Path:
    return machine_install_root(home) / "state"


def machine_install_state_path(home: Path | None = None) -> Path:
    return machine_state_root(home) / "machine-install.json"


def machine_install_history_path(home: Path | None = None) -> Path:
    return machine_state_root(home) / "install-history.jsonl"


def read_machine_install_state(home: Path | None = None) -> dict[str, Any] | None:
    path = machine_install_state_path(home)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (json.JSONDecodeError, OSError):
        return None


def compare_bundle_versions(left: str | None, right: str | None) -> int | None:
    if not left or not right:
        return None
    if left == right:
        return 0

    left_parts = _parse_semver_like(left)
    right_parts = _parse_semver_like(right)
    if left_parts is None or right_parts is None:
        return None

    left_core, left_prerelease = left_parts
    right_core, right_prerelease = right_parts

    max_length = max(len(left_core), len(right_core))
    left_core += (0,) * (max_length - len(left_core))
    right_core += (0,) * (max_length - len(right_core))

    if left_core < right_core:
        return -1
    if left_core > right_core:
        return 1

    left_rank = _release_suffix_rank(left_prerelease)
    right_rank = _release_suffix_rank(right_prerelease)
    if left_rank < right_rank:
        return -1
    if left_rank > right_rank:
        return 1
    if left_prerelease is None and right_prerelease is None:
        return 0

    prerelease_comparison = _compare_prerelease(left_prerelease, right_prerelease)
    if prerelease_comparison != 0:
        return prerelease_comparison

    return 0


def describe_machine_vs_project(machine_version: str | None, project_version: str | None) -> str:
    if not project_version:
        return "project_not_installed"
    if not machine_version:
        return "unknown"

    comparison = compare_bundle_versions(machine_version, project_version)
    if comparison is None:
        return "unknown"
    if comparison < 0:
        return "older"
    if comparison > 0:
        return "newer"
    return "same"


def _parse_semver_like(value: str) -> tuple[tuple[int, ...], tuple[str, ...] | None] | None:
    match = SEMVER_PATTERN.match(value.strip())
    if match is None:
        return None
    core = tuple(int(part) for part in match.group("core").split("."))
    prerelease_raw = match.group("prerelease")
    prerelease = tuple(prerelease_raw.split(".")) if prerelease_raw else None
    return core, prerelease


def _release_suffix_rank(prerelease: tuple[str, ...] | None) -> int:
    if prerelease is None:
        return 1
    first_token = prerelease[0].lower()
    if first_token in {"release", "hotfix"} or first_token.startswith(("release-", "hotfix-")):
        return 2
    return 0


def _compare_prerelease(left: tuple[str, ...], right: tuple[str, ...]) -> int:
    for left_token, right_token in zip(left, right):
        left_is_numeric = left_token.isdigit()
        right_is_numeric = right_token.isdigit()
        if left_is_numeric and right_is_numeric:
            left_number = int(left_token)
            right_number = int(right_token)
            if left_number < right_number:
                return -1
            if left_number > right_number:
                return 1
            continue
        if left_is_numeric and not right_is_numeric:
            return -1
        if right_is_numeric and not left_is_numeric:
            return 1
        if left_token < right_token:
            return -1
        if left_token > right_token:
            return 1

    if len(left) < len(right):
        return -1
    if len(left) > len(right):
        return 1
    return 0
