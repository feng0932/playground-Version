from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from .state import collect_status, safe_read_json


AUTHORITY_HOST = Path("00-项目包") / "04-过程文件" / "00-沟通记录与结论回写.md"
PRIMARY_WINDOW_AGENTS = {
    "01-编排-初始化项目包": "project_package_initialization",
    "10-执行-产品专家": "product_source_completion",
}
PROJECT_BASELINE_HOSTS = (
    Path("00-项目包") / "01-项目商业说明.md",
    Path("00-项目包") / "02-用户画像与权限架构.md",
    Path("00-项目包") / "03-系统拓扑与核心名词表.md",
    Path("00-项目包") / "05-项目级原型与高保真标准.md",
    Path("00-项目包") / "06-产品级共享资产底座.md",
)
FIXED_NOT_HUMAN_WINDOW_LITERAL = "当前不是对人窗口。"
RECORD_PATTERN = re.compile(
    r"^### (?P<label>Delivery Owner Record|Dispatch Snapshot Record) (?P<identifier>[^\n]+)\n```yaml\n(?P<payload>.*?)```",
    re.MULTILINE | re.DOTALL,
)
DISPATCH_CONTRACT_BLOCK_PATTERN = re.compile(
    r"### Dispatch Contract Block\n```yaml\n(?P<payload>.*?)\n```",
    re.DOTALL,
)


class RuntimeEntryError(Exception):
    def __init__(self, *, payload: dict[str, Any], exit_code: int = 1) -> None:
        super().__init__(str(payload.get("summary") or payload.get("decision") or "runtime entry failed"))
        self.payload = payload
        self.exit_code = exit_code


@dataclass
class StructuredRecord:
    label: str
    identifier: str
    payload: dict[str, Any]
    start: int
    end: int


@dataclass
class AuthorityCarrierState:
    path: Path
    text: str
    records: list[StructuredRecord]

    @property
    def latest_delivery_owner(self) -> StructuredRecord | None:
        for record in reversed(self.records):
            if record.label == "Delivery Owner Record":
                return record
        return None

    @property
    def latest_dispatch_snapshot(self) -> StructuredRecord | None:
        for record in reversed(self.records):
            if record.label == "Dispatch Snapshot Record":
                return record
        return None


def execute_runtime_action(
    project_root: Path,
    *,
    action: str,
    current_host: str | None = None,
    receipt_file: str | None = None,
    receipt_text: str | None = None,
) -> dict[str, Any]:
    runtime_root = _load_runtime_root(project_root)
    if action == "total_control_entry":
        return _handle_total_control_entry(project_root, runtime_root)
    if action == "window_continue":
        if not current_host:
            raise RuntimeEntryError(
                payload={
                    "ok": False,
                    "action": action,
                    "decision": "schema_error",
                    "summary": "--current-host is required for window_continue",
                },
                exit_code=2,
            )
        return _handle_window_continue(project_root, runtime_root, current_host=current_host)
    if action == "read_receipt":
        carrier_text = _resolve_receipt_text(project_root, receipt_file=receipt_file, receipt_text=receipt_text)
        return _handle_read_receipt(project_root, runtime_root, receipt_carrier=carrier_text)
    raise RuntimeEntryError(
        payload={
            "ok": False,
            "action": action,
            "decision": "schema_error",
            "summary": f"unsupported runtime action: {action}",
        },
        exit_code=2,
    )


def _handle_total_control_entry(project_root: Path, runtime_root: Path) -> dict[str, Any]:
    carrier = _ensure_authority_carrier(project_root)
    latest_delivery = carrier.latest_delivery_owner
    if latest_delivery is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "total_control_entry",
                "decision": "authority_blocked",
                "summary": "authority carrier is missing a Delivery Owner Record",
            }
        )
    retained_status = _extract_retained_latest_status(latest_delivery.payload)
    status_payload = collect_status(project_root)
    if str(status_payload.get("overall_state") or "").strip() != "ready":
        return _dispatch_via_resolver(
            project_root,
            runtime_root,
            action="total_control_entry",
            authority_snapshot=_build_authority_snapshot(
                latest_delivery.payload,
                dispatch_instance_id=_new_dispatch_instance_id("02"),
            ),
            latest_status={},
            dispatch_intent="install_runtime_check",
            dispatch_request={"target_agent": "02-编排-安装与运行检查"},
        )
    if _retained_receipt_unlocks_10(retained_status):
        authority_snapshot = _build_authority_snapshot(
            latest_delivery.payload,
            dispatch_instance_id=str(retained_status["dispatch_instance_id"]),
            retained_status=retained_status,
        )
        return _dispatch_via_resolver(
            project_root,
            runtime_root,
            action="total_control_entry",
            authority_snapshot=authority_snapshot,
            latest_status={},
            dispatch_intent="product_source_completion",
            dispatch_request={"target_agent": "10-执行-产品专家"},
        )
    if _project_baseline_missing(project_root):
        return _dispatch_via_resolver(
            project_root,
            runtime_root,
            action="total_control_entry",
            authority_snapshot=_build_authority_snapshot(
                latest_delivery.payload,
                dispatch_instance_id=_new_dispatch_instance_id("01"),
            ),
            latest_status={},
            dispatch_intent="project_package_initialization",
            dispatch_request={"target_agent": "01-编排-初始化项目包"},
        )
    return _dispatch_via_resolver(
        project_root,
        runtime_root,
        action="total_control_entry",
        authority_snapshot=_build_authority_snapshot(
            latest_delivery.payload,
            dispatch_instance_id=_new_dispatch_instance_id("10"),
            project_profile="historical_project",
        ),
        latest_status={},
        dispatch_intent="product_source_completion",
        dispatch_request={
            "target_agent": "10-执行-产品专家",
            "project_profile": "historical_project",
        },
    )


def _handle_window_continue(project_root: Path, runtime_root: Path, *, current_host: str) -> dict[str, Any]:
    carrier = _ensure_authority_carrier(project_root)
    snapshot_record = carrier.latest_dispatch_snapshot
    if snapshot_record is None:
        return _fixed_block_result(action="window_continue", current_host=current_host, reason="missing_dispatch_snapshot")
    target_agent = str(snapshot_record.payload.get("target_agent") or "").strip()
    if current_host != target_agent or current_host not in PRIMARY_WINDOW_AGENTS:
        return _fixed_block_result(action="window_continue", current_host=current_host, reason="current_not_human_window")
    handoff_spec = _handoff_spec_from_snapshot(snapshot_record.payload)
    prompt_text = _run_prompt_builder(runtime_root, handoff_spec=handoff_spec, project_root=project_root)
    return {
        "ok": True,
        "action": "window_continue",
        "decision": "continue_allowed",
        "dispatch_target": target_agent,
        "human_contact_owner": target_agent,
        "prompt_text": prompt_text,
        "fixed_user_reply": None,
        "authority_host": AUTHORITY_HOST.as_posix(),
    }


def _handle_read_receipt(project_root: Path, runtime_root: Path, *, receipt_carrier: str) -> dict[str, Any]:
    carrier = _ensure_authority_carrier(project_root)
    latest_delivery = carrier.latest_delivery_owner
    snapshot_record = carrier.latest_dispatch_snapshot
    if latest_delivery is None or snapshot_record is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": "missing active primary-window dispatch snapshot for /读取回执",
            }
        )
    active_snapshot = snapshot_record.payload
    current_agent = str(active_snapshot.get("target_agent") or "").strip()
    if current_agent not in PRIMARY_WINDOW_AGENTS:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": "latest dispatch snapshot is not a primary-window agent",
            }
        )
    authority_snapshot = _build_authority_snapshot(
        latest_delivery.payload,
        dispatch_instance_id=str(active_snapshot["dispatch_instance_id"]),
    )
    validation_payload = _run_json_helper(
        runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "validate_primary_window_receipt.py",
        {
            "authority_snapshot": authority_snapshot,
            "receipt_carrier": receipt_carrier,
        },
        project_root=project_root,
    )
    if validation_payload.get("ok") is not True:
        raise RuntimeEntryError(payload=_wrap_helper_failure("read_receipt", validation_payload))
    retained_status = _extract_retained_latest_status(latest_delivery.payload)
    consume_payload = _run_json_helper(
        runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "consume_total_control_receipt.py",
        {
            "validated_receipt": validation_payload["result"]["validated_receipt"],
            "authority_snapshot": authority_snapshot,
            "latest_receipt_consumption_status": retained_status,
        },
        project_root=project_root,
    )
    if consume_payload.get("ok") is not True:
        raise RuntimeEntryError(payload=_wrap_helper_failure("read_receipt", consume_payload))
    canonical_consume_result = dict(consume_payload["result"]["canonical_consume_result"])
    updated_delivery_payload = dict(latest_delivery.payload)
    updated_delivery_payload.update(_consume_result_to_retained_fields(canonical_consume_result))
    _rewrite_latest_delivery_owner(project_root, latest_delivery, updated_delivery_payload)
    refresh_carrier = _ensure_authority_carrier(project_root)
    refresh_delivery = refresh_carrier.latest_delivery_owner
    if refresh_delivery is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "authority_blocked",
                "summary": "authority carrier lost Delivery Owner Record after receipt consume",
            }
        )
    target_agent = str(canonical_consume_result.get("recommended_return_target") or "").strip()
    dispatch_intent = PRIMARY_WINDOW_AGENTS.get(target_agent)
    if dispatch_intent is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "read_receipt",
                "decision": "receipt_blocked",
                "summary": f"unsupported recommended_return_target for runtime receipt reopen: {target_agent or 'missing'}",
            }
        )
    refreshed_retained = _extract_retained_latest_status(refresh_delivery.payload)
    authority_for_rejudge = _build_authority_snapshot(
        refresh_delivery.payload,
        dispatch_instance_id=str(refreshed_retained["dispatch_instance_id"]),
        retained_status=refreshed_retained,
    )
    return _dispatch_via_resolver(
        project_root,
        runtime_root,
        action="read_receipt",
        authority_snapshot=authority_for_rejudge,
        latest_status={},
        dispatch_intent=dispatch_intent,
        dispatch_request={"target_agent": target_agent},
    )


def _dispatch_via_resolver(
    project_root: Path,
    runtime_root: Path,
    *,
    action: str,
    authority_snapshot: dict[str, Any],
    latest_status: dict[str, Any],
    dispatch_intent: str,
    dispatch_request: dict[str, Any],
) -> dict[str, Any]:
    resolver_payload = _run_json_helper(
        runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "resolve_route_and_window_state.py",
        {
            "authority_snapshot": authority_snapshot,
            "latest_consumed_receipt_status": latest_status,
            "dispatch_intent": dispatch_intent,
            "dispatch_request": dispatch_request,
        },
        project_root=project_root,
    )
    if resolver_payload.get("ok") is not True:
        raise RuntimeEntryError(payload=_wrap_helper_failure(action, resolver_payload))
    resolver_result = dict(resolver_payload["result"])
    if resolver_result.get("dispatch_allowed") is not True:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": action,
                "decision": str(resolver_payload.get("decision") or "dispatch_blocked"),
                "summary": "resolver did not authorize dispatch",
                "route_result": resolver_result,
                "errors": resolver_payload.get("errors", []),
            }
        )
    handoff_spec = dict(resolver_result["closed_handoff_spec"])
    prompt_text = _run_prompt_builder(runtime_root, handoff_spec=handoff_spec, project_root=project_root)
    snapshot_payload = _snapshot_payload_from_handoff_spec(handoff_spec, prompt_text=prompt_text)
    _append_dispatch_snapshot(project_root, snapshot_payload)
    if _requires_materialized_primary_window(handoff_spec=handoff_spec, resolver_result=resolver_result):
        return _staged_primary_window_dispatch_result(
            action=action,
            handoff_spec=handoff_spec,
            resolver_result=resolver_result,
        )
    return {
        "ok": True,
        "action": action,
        "decision": str(resolver_payload.get("decision") or "dispatch_allowed"),
        "dispatch_target": handoff_spec["agent"],
        "human_contact_owner": resolver_result.get("human_contact_owner"),
        "prompt_text": prompt_text,
        "fixed_user_reply": None,
        "authority_host": AUTHORITY_HOST.as_posix(),
        "route_result": resolver_result,
    }


def _load_runtime_root(project_root: Path) -> Path:
    payload = safe_read_json(project_root / ".ai-team" / "runtime.json")
    if not isinstance(payload, dict):
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "runtime_bootstrap",
                "decision": "runtime_missing",
                "summary": "runtime.json is missing or unreadable",
            }
        )
    bundle_root = payload.get("bundle_root")
    if not isinstance(bundle_root, str) or not bundle_root.strip():
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "runtime_bootstrap",
                "decision": "runtime_missing",
                "summary": "runtime.json is missing bundle_root",
            }
        )
    runtime_root = Path(bundle_root).expanduser().resolve()
    if not runtime_root.exists():
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "runtime_bootstrap",
                "decision": "runtime_missing",
                "summary": "runtime bundle root does not exist",
                "bundle_root": str(runtime_root),
            }
        )
    return runtime_root


def _resolve_receipt_text(project_root: Path, *, receipt_file: str | None, receipt_text: str | None) -> str:
    if receipt_text:
        return receipt_text
    if receipt_file:
        path = Path(receipt_file)
        if not path.is_absolute():
            path = (project_root / path).resolve()
        try:
            return path.read_text(encoding="utf-8")
        except OSError as exc:
            raise RuntimeEntryError(
                payload={
                    "ok": False,
                    "action": "read_receipt",
                    "decision": "schema_error",
                    "summary": f"receipt file could not be read: {exc}",
                },
                exit_code=2,
            ) from exc
    raise RuntimeEntryError(
        payload={
            "ok": False,
            "action": "read_receipt",
            "decision": "schema_error",
            "summary": "read_receipt requires --receipt-file or --receipt-text",
        },
        exit_code=2,
    )


def _run_json_helper(script_path: Path, payload: dict[str, Any], *, project_root: Path) -> dict[str, Any]:
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".json", delete=False) as tmp:
        tmp_path = Path(tmp.name)
        tmp.write(json.dumps(payload, ensure_ascii=False, indent=2))
    try:
        env = _build_runtime_subprocess_env()
        result = subprocess.run(
            [sys.executable, str(script_path), "--input-json", str(tmp_path)],
            cwd=project_root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
    finally:
        tmp_path.unlink(missing_ok=True)
    try:
        output = json.loads(result.stdout.strip() or "{}")
    except json.JSONDecodeError as exc:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "runtime_helper",
                "decision": "runtime_error",
                "summary": f"helper emitted non-JSON stdout: {script_path.name}",
                "stderr": result.stderr,
                "stdout": result.stdout,
            }
        ) from exc
    if not isinstance(output, dict):
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "runtime_helper",
                "decision": "runtime_error",
                "summary": f"helper emitted non-mapping verdict: {script_path.name}",
                "stderr": result.stderr,
                "stdout": result.stdout,
            }
        )
    return output


def _run_prompt_builder(runtime_root: Path, *, handoff_spec: dict[str, Any], project_root: Path) -> str:
    builder_path = runtime_root / "org_skills" / "00-dispatch-orchestration" / "scripts" / "build_dispatch_prompt.py"
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", suffix=".json", delete=False) as tmp:
        tmp_path = Path(tmp.name)
        tmp.write(json.dumps(handoff_spec, ensure_ascii=False, indent=2))
    try:
        env = _build_runtime_subprocess_env()
        result = subprocess.run(
            [sys.executable, str(builder_path), "--handoff-spec", str(tmp_path)],
            cwd=project_root,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
    finally:
        tmp_path.unlink(missing_ok=True)
    if result.returncode != 0:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "build_dispatch_prompt",
                "decision": "runtime_error",
                "summary": "build_dispatch_prompt failed",
                "stderr": result.stderr.strip(),
            }
        )
    prompt_text = result.stdout.strip()
    if not prompt_text:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "build_dispatch_prompt",
                "decision": "runtime_error",
                "summary": "build_dispatch_prompt returned empty stdout",
            }
        )
    return prompt_text


def _ensure_authority_carrier(project_root: Path) -> AuthorityCarrierState:
    path = project_root / AUTHORITY_HOST
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_bootstrap_authority_carrier_text(), encoding="utf-8")
    text = path.read_text(encoding="utf-8")
    records: list[StructuredRecord] = []
    for match in RECORD_PATTERN.finditer(text):
        payload = yaml.safe_load(match.group("payload")) or {}
        if not isinstance(payload, dict):
            payload = {}
        records.append(
            StructuredRecord(
                label=match.group("label"),
                identifier=match.group("identifier").strip(),
                payload=dict(payload),
                start=match.start(),
                end=match.end(),
            )
        )
    return AuthorityCarrierState(path=path, text=text, records=records)


def _build_runtime_subprocess_env() -> dict[str, str]:
    env = os.environ.copy()
    launcher_src_root = str(Path(__file__).resolve().parents[1])
    existing_pythonpath = env.get("PYTHONPATH", "").strip()
    pythonpath_parts = [launcher_src_root]
    if existing_pythonpath:
        pythonpath_parts.append(existing_pythonpath)
    env["PYTHONPATH"] = os.pathsep.join(pythonpath_parts)
    return env


def _bootstrap_authority_carrier_text() -> str:
    payload = {
        "schema": "total_control.delivery_owner_record.v1",
        "task_chain_id": "tc-runtime-entry-bootstrap",
        "task_chain_epoch": 1,
        "authority_record_version": 1,
        "scope_level": "project",
        "scope_path": "00-项目包/04-过程文件/00-沟通记录与结论回写.md",
        "当前责任模式": "standard",
        "模式来源": "runtime_entry_bootstrap",
        "二次握手结果": "confirmed",
        "锁存范围": "runtime_entry_scope",
        "退出条件": "control_receipt_consumed",
        "当前状态": "standard",
    }
    return "# 沟通记录与结论回写\n\n" + _render_record(
        label="Delivery Owner Record",
        identifier="tc-runtime-entry-bootstrap#1",
        payload=payload,
    )


def _render_record(*, label: str, identifier: str, payload: dict[str, Any]) -> str:
    yaml_text = yaml.safe_dump(payload, allow_unicode=True, sort_keys=False).rstrip()
    return f"### {label} {identifier}\n```yaml\n{yaml_text}\n```\n"


def _rewrite_latest_delivery_owner(project_root: Path, record: StructuredRecord, payload: dict[str, Any]) -> None:
    carrier = _ensure_authority_carrier(project_root)
    refreshed_record = carrier.latest_delivery_owner
    if refreshed_record is None:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "authority_writeback",
                "decision": "authority_blocked",
                "summary": "authority carrier is missing Delivery Owner Record",
            }
        )
    new_block = _render_record(label=refreshed_record.label, identifier=refreshed_record.identifier, payload=payload)
    updated_text = carrier.text[: refreshed_record.start] + new_block + carrier.text[refreshed_record.end :]
    carrier.path.write_text(updated_text, encoding="utf-8")


def _append_dispatch_snapshot(project_root: Path, payload: dict[str, Any]) -> None:
    carrier = _ensure_authority_carrier(project_root)
    append_block = _render_record(
        label="Dispatch Snapshot Record",
        identifier=str(payload["dispatch_instance_id"]),
        payload=payload,
    )
    stripped = carrier.text.rstrip()
    separator = "\n\n" if stripped else ""
    carrier.path.write_text(stripped + separator + append_block, encoding="utf-8")


def _extract_retained_latest_status(delivery_payload: dict[str, Any]) -> dict[str, Any]:
    field_map = {
        "latest_consumed_receipt_consumed": "receipt_consumed",
        "latest_consumed_receipt_dispatch_instance_id": "dispatch_instance_id",
        "latest_consumed_receipt_task_chain_id": "task_chain_id",
        "latest_consumed_receipt_task_chain_epoch": "task_chain_epoch",
        "latest_consumed_receipt_child_thread": "child_thread",
        "latest_consumed_receipt_current_phase": "current_phase",
        "latest_consumed_receipt_return_reason": "return_reason",
        "latest_consumed_receipt_recommended_return_target": "recommended_return_target",
        "latest_consumed_receipt_recommended_total_control_state": "recommended_total_control_state",
    }
    retained: dict[str, Any] = {}
    for source_key, target_key in field_map.items():
        if source_key not in delivery_payload:
            continue
        value = delivery_payload[source_key]
        if target_key == "receipt_consumed":
            retained[target_key] = _parse_boolish(value)
        else:
            retained[target_key] = value
    return retained


def _retained_receipt_unlocks_10(retained_status: dict[str, Any]) -> bool:
    required = [
        retained_status.get("receipt_consumed") is True,
        retained_status.get("child_thread") == "01-编排-初始化项目包",
        retained_status.get("return_reason") == "completed",
        retained_status.get("recommended_return_target") == "10-执行-产品专家",
        retained_status.get("recommended_total_control_state") == "project_baseline_ready_10_unlocked",
    ]
    return all(required)


def _project_baseline_missing(project_root: Path) -> bool:
    return any(not (project_root / path).exists() for path in PROJECT_BASELINE_HOSTS)


def _build_authority_snapshot(
    delivery_payload: dict[str, Any],
    *,
    dispatch_instance_id: str,
    retained_status: dict[str, Any] | None = None,
    project_profile: str | None = None,
) -> dict[str, Any]:
    snapshot = {
        "dispatch_instance_id": dispatch_instance_id,
        "task_chain_id": str(delivery_payload.get("task_chain_id") or "tc-runtime-entry-bootstrap"),
        "task_chain_epoch": int(delivery_payload.get("task_chain_epoch") or 1),
    }
    if project_profile:
        snapshot["project_profile"] = project_profile
    retained_status = retained_status or {}
    reverse_field_map = {
        "receipt_consumed": "latest_consumed_receipt_consumed",
        "dispatch_instance_id": "latest_consumed_receipt_dispatch_instance_id",
        "task_chain_id": "latest_consumed_receipt_task_chain_id",
        "task_chain_epoch": "latest_consumed_receipt_task_chain_epoch",
        "child_thread": "latest_consumed_receipt_child_thread",
        "current_phase": "latest_consumed_receipt_current_phase",
        "return_reason": "latest_consumed_receipt_return_reason",
        "recommended_return_target": "latest_consumed_receipt_recommended_return_target",
        "recommended_total_control_state": "latest_consumed_receipt_recommended_total_control_state",
    }
    for status_key, authority_key in reverse_field_map.items():
        if status_key not in retained_status:
            continue
        snapshot[authority_key] = retained_status[status_key]
    return snapshot


def _consume_result_to_retained_fields(canonical_consume_result: dict[str, Any]) -> dict[str, Any]:
    field_map = {
        "receipt_consumed": "latest_consumed_receipt_consumed",
        "dispatch_instance_id": "latest_consumed_receipt_dispatch_instance_id",
        "task_chain_id": "latest_consumed_receipt_task_chain_id",
        "task_chain_epoch": "latest_consumed_receipt_task_chain_epoch",
        "child_thread": "latest_consumed_receipt_child_thread",
        "current_phase": "latest_consumed_receipt_current_phase",
        "return_reason": "latest_consumed_receipt_return_reason",
        "recommended_return_target": "latest_consumed_receipt_recommended_return_target",
        "recommended_total_control_state": "latest_consumed_receipt_recommended_total_control_state",
    }
    retained_fields: dict[str, Any] = {}
    for source_key, target_key in field_map.items():
        if source_key not in canonical_consume_result:
            continue
        retained_fields[target_key] = canonical_consume_result[source_key]
    return retained_fields


def _snapshot_payload_from_handoff_spec(handoff_spec: dict[str, Any], *, prompt_text: str) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "schema": "total_control.dispatch_snapshot_record.v1",
        "dispatch_schema_version": 1,
        "dispatch_instance_id": handoff_spec["dispatch_instance_id"],
        "task_chain_id": handoff_spec["task_chain_id"],
        "task_chain_epoch": handoff_spec["task_chain_epoch"],
        "target_agent": handoff_spec["agent"],
        "role_prompt_source": handoff_spec["role_prompt_source"],
        "writable_targets": handoff_spec["writable_targets"],
        "allow_direct_user_question": handoff_spec["allow_direct_user_question"],
        "allowed_user_question_scope": handoff_spec["allowed_user_question_scope"],
        "input_package": handoff_spec["input_package"],
        "dispatch_intent": handoff_spec["dispatch_intent"],
    }
    for optional_key in ("dod", "receipt_contract", "blocker_scope", "window_activation_snapshot"):
        if optional_key in handoff_spec:
            payload[optional_key] = handoff_spec[optional_key]
    contract_payload = _extract_dispatch_contract_payload(prompt_text)
    role_prompt_sha256 = contract_payload.get("role_prompt_sha256")
    if isinstance(role_prompt_sha256, str) and role_prompt_sha256.strip():
        payload["role_prompt_sha256"] = role_prompt_sha256.strip()
    return payload


def _extract_dispatch_contract_payload(prompt_text: str) -> dict[str, Any]:
    match = DISPATCH_CONTRACT_BLOCK_PATTERN.search(prompt_text)
    if not match:
        return {}
    payload = yaml.safe_load(match.group("payload")) or {}
    if not isinstance(payload, dict):
        return {}
    return dict(payload)


def _handoff_spec_from_snapshot(snapshot_payload: dict[str, Any]) -> dict[str, Any]:
    required_keys = (
        "target_agent",
        "role_prompt_source",
        "dispatch_instance_id",
        "task_chain_id",
        "task_chain_epoch",
        "writable_targets",
        "allow_direct_user_question",
        "allowed_user_question_scope",
        "dispatch_intent",
    )
    missing_keys = [key for key in required_keys if key not in snapshot_payload]
    if missing_keys:
        raise RuntimeEntryError(
            payload={
                "ok": False,
                "action": "window_continue",
                "decision": "authority_blocked",
                "summary": "dispatch snapshot is missing required fields: " + ", ".join(missing_keys),
            }
        )
    handoff_spec: dict[str, Any] = {
        "label": f"继续{snapshot_payload['target_agent']}",
        "agent": snapshot_payload["target_agent"],
        "role_prompt_source": snapshot_payload["role_prompt_source"],
        "dispatch_instance_id": snapshot_payload["dispatch_instance_id"],
        "task_chain_id": snapshot_payload["task_chain_id"],
        "task_chain_epoch": snapshot_payload["task_chain_epoch"],
        "writable_targets": snapshot_payload["writable_targets"],
        "allow_direct_user_question": _parse_boolish(snapshot_payload["allow_direct_user_question"]),
        "allowed_user_question_scope": str(snapshot_payload["allowed_user_question_scope"]),
        "input_package": snapshot_payload.get(
            "input_package",
            {
                "goal": f"Continue {snapshot_payload['target_agent']} from runtime dispatch snapshot.",
                "source": "ai_team_installer.runtime_entry",
            },
        ),
        "dispatch_intent": snapshot_payload["dispatch_intent"],
    }
    for optional_key in ("dod", "receipt_contract", "blocker_scope", "window_activation_snapshot"):
        if optional_key in snapshot_payload:
            handoff_spec[optional_key] = snapshot_payload[optional_key]
    return handoff_spec


def _fixed_block_result(*, action: str, current_host: str, reason: str) -> dict[str, Any]:
    return {
        "ok": True,
        "action": action,
        "decision": "current_not_human_window",
        "dispatch_target": None,
        "human_contact_owner": current_host,
        "prompt_text": None,
        "fixed_user_reply": FIXED_NOT_HUMAN_WINDOW_LITERAL,
        "authority_host": AUTHORITY_HOST.as_posix(),
        "block_reason": reason,
    }


def _requires_materialized_primary_window(
    *,
    handoff_spec: dict[str, Any],
    resolver_result: dict[str, Any],
) -> bool:
    target_agent = str(handoff_spec.get("agent") or "").strip()
    return (
        target_agent in PRIMARY_WINDOW_AGENTS
        and resolver_result.get("window_state") == "active"
        and resolver_result.get("human_contact_mode") == "direct_primary_window"
    )


def _staged_primary_window_dispatch_result(
    *,
    action: str,
    handoff_spec: dict[str, Any],
    resolver_result: dict[str, Any],
) -> dict[str, Any]:
    target_agent = str(handoff_spec["agent"])
    activation_command = f'ai-team runtime --action window_continue --current-host "{target_agent}"'
    return {
        "ok": True,
        "action": action,
        "decision": "dispatch_recorded",
        "dispatch_target": target_agent,
        "human_contact_owner": resolver_result.get("human_contact_owner"),
        "prompt_text": None,
        "fixed_user_reply": (
            f"当前 root 线程只完成了 `{target_agent}` 的派发登记；"
            f"请在真实 `{target_agent}` 主窗口执行 `{activation_command}`，"
            "不得在当前 root 线程代演 `01 / 10`。"
        ),
        "authority_host": AUTHORITY_HOST.as_posix(),
        "route_result": resolver_result,
        "activation_required": True,
        "activation_mode": "materialized_primary_window",
        "activation_command": activation_command,
    }


def _wrap_helper_failure(action: str, payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "ok": False,
        "action": action,
        "decision": payload.get("decision", "runtime_error"),
        "summary": f"helper returned fail-closed verdict: {payload.get('script', 'unknown helper')}",
        "helper_result": payload.get("result", {}),
        "errors": payload.get("errors", []),
    }


def _new_dispatch_instance_id(prefix: str) -> str:
    return f"dispatch-{prefix.lower()}-{uuid.uuid4().hex[:12]}"


def _parse_boolish(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes"}:
            return True
        if normalized in {"false", "0", "no"}:
            return False
    return bool(value)
