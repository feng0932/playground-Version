from __future__ import annotations

import re
from typing import Any


HUMAN_ENTRY_COMMAND = "/总控 请接管当前项目，并授权派发子agent"

REASON_TO_FAILURE_CATEGORY = {
    "release_metadata_missing": "release_metadata_unavailable",
    "release_metadata_unreadable": "release_metadata_unavailable",
    "release_metadata_invalid": "release_metadata_invalid",
    "release_metadata_untrusted": "release_metadata_invalid",
    "runtime_bundle_source_missing": "runtime_materialization_failed",
    "governance_script_diverged": "runtime_materialization_failed",
    "methodology_source_repo_root_forbidden": "permission_denied",
    "downgrade_blocked": "downgrade_blocked",
}

FORBIDDEN_HUMAN_OUTPUT_PATTERNS = (
    re.compile(r"https?://", re.I),
    re.compile(r"\b[a-f0-9]{64}\b", re.I),
    re.compile(r"release metadata:", re.I),
    re.compile(r"archive:", re.I),
    re.compile(r"launcher:", re.I),
    re.compile(r"installer_archive_sha256", re.I),
    re.compile(r"bundle_sha256", re.I),
    re.compile(r"prompt_source", re.I),
    re.compile(r"Traceback", re.I),
    re.compile(r"PowerShell.*Exception", re.I),
    re.compile(r"^\s*[{[]", re.M),
)


def failure_category_for_reason(reason_code: object) -> str:
    if not isinstance(reason_code, str) or not reason_code.strip():
        return "install_blocked"
    return REASON_TO_FAILURE_CATEGORY.get(reason_code.strip(), reason_code.strip())


def _single_line(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def format_install_success(payload: dict[str, Any]) -> str:
    bundle_version = _single_line(payload.get("bundle_version") or "unknown")
    log_path = _single_line(payload.get("log_path") or payload.get("install_summary_path") or "")
    return "\n".join(
        [
            f"安装完成：ai-team {bundle_version} 已接入当前项目。",
            "下一步：在项目根目录打开 Codex，输入：",
            HUMAN_ENTRY_COMMAND,
            f"日志：{log_path}",
        ]
    )


def format_install_failure(payload: dict[str, Any]) -> str:
    failure_category = _single_line(
        payload.get("failure_category")
        or failure_category_for_reason(payload.get("reason_code"))
        or "install_blocked"
    )
    reason = _single_line(
        payload.get("human_readable_reason")
        or payload.get("summary")
        or "安装执行链未完成。"
    )
    next_step = _single_line(
        payload.get("next_step")
        or payload.get("suggested_action")
        or "查看日志确认原因后重新运行 ai-team install。"
    )
    log_path = _single_line(payload.get("log_path") or "")
    return "\n".join(
        [
            f"安装未完成：{failure_category}",
            f"原因：{reason}",
            f"下一步：{next_step}",
            f"日志：{log_path}",
        ]
    )


def lint_human_install_output(text: str) -> list[str]:
    errors: list[str] = []
    for pattern in FORBIDDEN_HUMAN_OUTPUT_PATTERNS:
        if pattern.search(text):
            errors.append(f"human install output leaked forbidden pattern: {pattern.pattern}")
    if "安装完成：" in text:
        for required in ("下一步：在项目根目录打开 Codex，输入：", HUMAN_ENTRY_COMMAND, "日志："):
            if required not in text:
                errors.append(f"success output missing required human field: {required}")
    if "安装未完成：" in text:
        for required in ("原因：", "下一步：", "日志："):
            if required not in text:
                errors.append(f"failure output missing required human field: {required}")
    return errors
