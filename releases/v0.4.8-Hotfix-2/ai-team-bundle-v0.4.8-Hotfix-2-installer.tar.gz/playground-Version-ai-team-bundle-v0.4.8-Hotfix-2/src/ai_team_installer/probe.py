from __future__ import annotations

import json
from pathlib import Path


IGNORE_RULES = (
    ".ai-team/",
)
PROJECT_PACKAGE_FORMAL_TARGETS_CONTRACT = (
    "install/default_bundle/assets/contracts/project_package_formal_targets.json"
)


def ensure_hidden_workspace_ignored(project_root: Path) -> str:
    exclude_file = project_root / ".git" / "info" / "exclude"
    if exclude_file.parent.exists():
        exclude_file.parent.mkdir(parents=True, exist_ok=True)
        return _ensure_rules(exclude_file)

    gitignore_file = project_root / ".gitignore"
    return _ensure_rules(gitignore_file)


def _ensure_rules(path: Path) -> str:
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    rules = existing.splitlines()
    missing_rules = [rule for rule in IGNORE_RULES if rule not in rules]
    if missing_rules:
        if existing and not existing.endswith("\n"):
            existing += "\n"
        existing += "".join(f"{rule}\n" for rule in missing_rules)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(existing, encoding="utf-8")
    return str(path)


def _contract_path() -> Path:
    current = Path(__file__).resolve()
    for parent in current.parents:
        candidate = parent / PROJECT_PACKAGE_FORMAL_TARGETS_CONTRACT
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(f"missing project package formal targets contract: {PROJECT_PACKAGE_FORMAL_TARGETS_CONTRACT}")


def project_package_formal_targets() -> list[tuple[str, str]]:
    payload = json.loads(_contract_path().read_text(encoding="utf-8"))
    targets = payload.get("targets")
    if not isinstance(targets, list):
        raise ValueError("project_package_formal_targets targets must be a list")
    formal_targets: list[tuple[str, str]] = []
    for index, entry in enumerate(targets, start=1):
        if not isinstance(entry, dict):
            continue
        project_target = entry.get("project_target")
        probe_field = entry.get("probe_field") or f"has_project_baseline_{index:02d}"
        if isinstance(project_target, str) and project_target.strip() and isinstance(probe_field, str):
            formal_targets.append((probe_field.strip(), project_target.strip()))
    if not formal_targets:
        raise ValueError("project_package_formal_targets must define project targets")
    return formal_targets


def probe_structure(project_root: Path) -> dict[str, object]:
    formal_targets = project_package_formal_targets()
    baseline_facts = {
        field_name: (project_root / relative_path).exists()
        for field_name, relative_path in formal_targets
    }
    missing_targets = [
        relative_path
        for field_name, relative_path in formal_targets
        if not baseline_facts[field_name]
    ]
    return {
        "project_root": str(project_root),
        "facts": {
            "has_git_repo": (project_root / ".git").exists(),
            "has_readme": (project_root / "README.md").exists(),
            "has_src_dir": (project_root / "src").exists(),
            "has_tests_dir": (project_root / "tests").exists(),
            "has_project_package_dir": (project_root / "00-项目包").exists(),
            **baseline_facts,
            "project_package_ready": not missing_targets,
            "project_package_missing_targets": missing_targets,
            "has_module_execution_dir": (project_root / "01-模块执行包").exists(),
            "has_submission_package_dir": (project_root / "80-完整提交包").exists(),
            "has_submission_status_json": (project_root / "80-完整提交包" / "00-提交状态.json").exists(),
            "has_legacy_toolkit_dir": (project_root / ".ai-team" / "toolkit").exists(),
            "has_docs_root_note": (project_root / "docs" / "00-说明.md").exists(),
            "has_docs_cross_module_readme": (project_root / "docs" / "01-跨模块补充资料" / "README.md").exists(),
        },
    }
