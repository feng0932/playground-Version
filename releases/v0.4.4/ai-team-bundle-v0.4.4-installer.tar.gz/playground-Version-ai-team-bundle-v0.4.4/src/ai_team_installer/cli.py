from __future__ import annotations

import argparse
import json
from pathlib import Path

from .doctor import collect_doctor
from .install import InstallBlockedError, install_project
from .runtime_entry import RuntimeEntryError, execute_runtime_action
from .state import collect_status


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ai_team_installer")
    subparsers = parser.add_subparsers(dest="command", required=True)

    install_parser = subparsers.add_parser("install")
    install_parser.add_argument("--project-root", required=False)
    install_parser.add_argument("--allow-downgrade", action="store_true")
    install_parser.add_argument("--repair-governance-scripts", action="store_true")

    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("--project-root", required=False)

    doctor_parser = subparsers.add_parser("doctor")
    doctor_parser.add_argument("--project-root", required=False)

    runtime_parser = subparsers.add_parser("runtime")
    runtime_parser.add_argument("--project-root", required=False)
    runtime_parser.add_argument(
        "--action",
        required=True,
        choices=["total_control_entry", "window_continue", "read_receipt"],
    )
    runtime_parser.add_argument("--current-host", required=False)
    runtime_parser.add_argument("--receipt-file", required=False)
    runtime_parser.add_argument("--receipt-text", required=False)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    project_root_arg = getattr(args, "project_root", None)
    project_root = Path(project_root_arg).resolve() if project_root_arg else Path.cwd().resolve()

    if args.command == "install":
        try:
            result = install_project(
                project_root,
                allow_downgrade=args.allow_downgrade,
                repair_governance_scripts=args.repair_governance_scripts,
            )
        except InstallBlockedError as exc:
            print(json.dumps(exc.payload, ensure_ascii=False, indent=2))
            return 1
        print("[ai-team] install: ok")
        for warning in result.get("warnings", []):
            print(f"warning: {warning}")
        print()
        print("Next prompt:")
        print(result["startup_prompt"])
        return 0

    if args.command == "status":
        print(json.dumps(collect_status(project_root), ensure_ascii=False, indent=2))
        return 0

    if args.command == "doctor":
        print(json.dumps(collect_doctor(project_root), ensure_ascii=False, indent=2))
        return 0

    if args.command == "runtime":
        try:
            payload = execute_runtime_action(
                project_root,
                action=args.action,
                current_host=args.current_host,
                receipt_file=args.receipt_file,
                receipt_text=args.receipt_text,
            )
        except RuntimeEntryError as exc:
            print(json.dumps(exc.payload, ensure_ascii=False, indent=2))
            return exc.exit_code
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    parser.error(f"unsupported command: {args.command}")
    return 2
